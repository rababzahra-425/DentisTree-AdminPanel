// import React, { useState, useRef } from 'react';
// import './Settings.css';

// // ── SVG Icons ─────────────────────────────────────────────────────────────
// const IcUser = () => (
//   <svg viewBox="0 0 20 20" fill="none">
//     <circle cx="10" cy="7" r="3.5" stroke="currentColor" strokeWidth="1.5"/>
//     <path d="M2.5 18c0-3.87 3.36-6.5 7.5-6.5s7.5 2.63 7.5 6.5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
//   </svg>
// );
// const IcShield = () => (
//   <svg viewBox="0 0 20 20" fill="none">
//     <path d="M10 2l6 2.5v5c0 3.5-2.5 6.5-6 8-3.5-1.5-6-4.5-6-8v-5L10 2z" stroke="currentColor" strokeWidth="1.5" strokeLinejoin="round"/>
//   </svg>
// );
// const IcBell = () => (
//   <svg viewBox="0 0 20 20" fill="none">
//     <path d="M10 2.5A5.5 5.5 0 004.5 8v3.5L3 13h14l-1.5-1.5V8A5.5 5.5 0 0010 2.5z" stroke="currentColor" strokeWidth="1.5" strokeLinejoin="round"/>
//     <path d="M8 13v.5a2 2 0 004 0V13" stroke="currentColor" strokeWidth="1.3"/>
//   </svg>
// );
// const IcMoon = () => (
//   <svg viewBox="0 0 20 20" fill="none">
//     <path d="M17.5 11.5A7.5 7.5 0 018.5 2.5a7.5 7.5 0 100 15 7.5 7.5 0 009-6z" stroke="currentColor" strokeWidth="1.5" strokeLinejoin="round"/>
//   </svg>
// );
// const IcLock = () => (
//   <svg viewBox="0 0 20 20" fill="none">
//     <rect x="4" y="9" width="12" height="9" rx="2" stroke="currentColor" strokeWidth="1.5"/>
//     <path d="M7 9V7a3 3 0 016 0v2" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
//   </svg>
// );
// const IcCamera = () => (
//   <svg viewBox="0 0 20 20" fill="none">
//     <path d="M2 6.5A1.5 1.5 0 013.5 5h1.2L6 3h8l1.3 2h1.2A1.5 1.5 0 0118 6.5v9A1.5 1.5 0 0116.5 17h-13A1.5 1.5 0 012 15.5v-9z" stroke="currentColor" strokeWidth="1.5"/>
//     <circle cx="10" cy="11" r="2.5" stroke="currentColor" strokeWidth="1.3"/>
//   </svg>
// );
// const IcCheck = () => (
//   <svg viewBox="0 0 20 20" fill="none">
//     <circle cx="10" cy="10" r="8" stroke="currentColor" strokeWidth="1.5"/>
//     <path d="M6.5 10l2.5 2.5 4-4" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
//   </svg>
// );
// const IcAlert = () => (
//   <svg viewBox="0 0 20 20" fill="none">
//     <circle cx="10" cy="10" r="8" stroke="currentColor" strokeWidth="1.5"/>
//     <path d="M10 7v3M10 13h.01" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
//   </svg>
// );
// const IcEye = () => (
//   <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
//     <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/>
//     <circle cx="12" cy="12" r="3"/>
//   </svg>
// );
// const IcEyeOff = () => (
//   <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
//     <path d="M17.94 17.94A10.07 10.07 0 0112 20c-7 0-11-8-11-8a18.45 18.45 0 015.06-5.94M9.9 4.24A9.12 9.12 0 0112 4c7 0 11 8 11 8a18.5 18.5 0 01-2.16 3.19m-6.72-1.07a3 3 0 11-4.24-4.24"/>
//     <line x1="1" y1="1" x2="23" y2="23"/>
//   </svg>
// );
// const IcSun = () => (
//   <svg viewBox="0 0 20 20" fill="none">
//     <circle cx="10" cy="10" r="3.5" stroke="currentColor" strokeWidth="1.5"/>
//     <path d="M10 2v2M10 16v2M2 10h2M16 10h2M4.22 4.22l1.42 1.42M14.36 14.36l1.42 1.42M4.22 15.78l1.42-1.42M14.36 5.64l1.42-1.42" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
//   </svg>
// );
// const IcSave = () => (
//   <svg viewBox="0 0 20 20" fill="none">
//     <path d="M3 4a1 1 0 011-1h9l4 4v9a1 1 0 01-1 1H4a1 1 0 01-1-1V4z" stroke="currentColor" strokeWidth="1.5" strokeLinejoin="round"/>
//     <path d="M7 3v4h6V3M7 13h6" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round"/>
//   </svg>
// );
// const IcLoader = () => (
//   <svg viewBox="0 0 20 20" fill="none" className="spin-icon">
//     <circle cx="10" cy="10" r="7" stroke="currentColor" strokeWidth="1.5" strokeDasharray="30" strokeDashoffset="10"/>
//   </svg>
// );

// // ── Sub-components ─────────────────────────────────────────────────────────
// function Toggle({ checked, onChange }) {
//   return (
//     <label className="st-toggle">
//       <input type="checkbox" checked={checked} onChange={e => onChange(e.target.checked)} />
//       <span className="st-slider" />
//     </label>
//   );
// }

// function ToggleRow({ label, desc, checked, onChange, last }) {
//   return (
//     <div className={`st-toggle-row${last ? ' last' : ''}`}>
//       <div className="st-toggle-info">
//         <strong>{label}</strong>
//         {desc && <span>{desc}</span>}
//       </div>
//       <Toggle checked={checked} onChange={onChange} />
//     </div>
//   );
// }

// function Toast({ type, msg, onClose }) {
//   if (!msg) return null;
//   return (
//     <div className={`st-toast st-toast-${type}`}>
//       <span className="st-toast-icon">{type === 'success' ? <IcCheck /> : <IcAlert />}</span>
//       <span className="st-toast-msg">{msg}</span>
//       <button className="st-toast-close" onClick={onClose} aria-label="Close">✕</button>
//     </div>
//   );
// }

// function PwdInput({ value, onChange, placeholder, id }) {
//   const [show, setShow] = useState(false);
//   return (
//     <div className="st-pwd-wrap">
//       <input
//         id={id}
//         type={show ? 'text' : 'password'}
//         value={value}
//         onChange={onChange}
//         placeholder={placeholder}
//         autoComplete="new-password"
//       />
//       <button
//         type="button"
//         className="st-eye-btn"
//         onClick={() => setShow(s => !s)}
//         aria-label={show ? 'Hide password' : 'Show password'}
//       >
//         {show ? <IcEyeOff /> : <IcEye />}
//       </button>
//     </div>
//   );
// }

// function getStrength(pwd) {
//   if (!pwd) return { pct: 0, label: '', color: '' };
//   let s = 0;
//   if (pwd.length >= 8) s++;
//   if (/[A-Z]/.test(pwd)) s++;
//   if (/[0-9]/.test(pwd)) s++;
//   if (/[^A-Za-z0-9]/.test(pwd)) s++;
//   const map = [
//     { pct: 15, label: 'Too short', color: '#ef4444' },
//     { pct: 35, label: 'Weak', color: '#f97316' },
//     { pct: 60, label: 'Fair', color: '#eab308' },
//     { pct: 80, label: 'Good', color: '#22c55e' },
//     { pct: 100, label: 'Strong', color: '#16a34a' },
//   ];
//   return map[Math.min(s, 4)];
// }

// // ── TABS CONFIG ────────────────────────────────────────────────────────────
// const TABS = [
//   { id: 'profile',      label: 'Profile',       Icon: IcUser    },
//   { id: 'security',     label: 'Security',      Icon: IcShield  },
//   { id: 'appearance',   label: 'Appearance',    Icon: IcMoon    },
//   { id: 'notifications',label: 'Notifications', Icon: IcBell    },
// ];

// // ── MAIN COMPONENT ─────────────────────────────────────────────────────────
// export default function Settings({ user }) {
//   const [tab, setTab]         = useState('profile');
//   const [toast, setToast]     = useState({ type: '', msg: '' });
//   const [saving, setSaving]   = useState(false);
//   const fileRef               = useRef();

//   // ── Profile state
//   const defaultProfile = {
//     fullName:  user?.full_name || 'Administrator',
//     username:  user?.username  || 'admin',
//     email:     user?.email     || 'admin@dentistree.pk',
//     phone:     user?.phone     || '+92 300 0000000',
//     clinic:    'Dentistree Clinic',
//     role:      user?.is_superuser ? 'Super Admin' : 'User',
//   };
//   const [profile, setProfile]         = useState(defaultProfile);
//   const [saved, setSaved]             = useState(defaultProfile);
//   const [photoSrc, setPhotoSrc]       = useState(null);
//   const [profileDirty, setProfileDirty] = useState(false);

//   const updateProfile = (key, val) => {
//     setProfile(p => ({ ...p, [key]: val }));
//     setProfileDirty(true);
//   };

//   // ── Password state
//   const [curPwd,     setCurPwd]     = useState('');
//   const [newPwd,     setNewPwd]     = useState('');
//   const [confirmPwd, setConfirmPwd] = useState('');
//   const strength = getStrength(newPwd);

//   // ── Appearance
//   const [darkMode, setDarkMode] = useState(false);

//   // ── Notifications
//   const [notifs, setNotifs] = useState({
//     newAppointments: true,
//     reminders:       true,
//     reviews:         false,
//     inventory:       true,
//     reports:         false,
//     systemAlerts:    true,
//     staffUpdates:    false,
//     invoices:        true,
//   });

//   // ── 2FA / Security
//   const [sms2fa,      setSms2fa]      = useState(false);
//   const [app2fa,      setApp2fa]      = useState(true);
//   const [emailVerify, setEmailVerify] = useState(false);

//   // ── Helpers
//   const showToast = (type, msg) => {
//     setToast({ type, msg });
//     setTimeout(() => setToast({ type: '', msg: '' }), 3500);
//   };

//   const simulate = (cb) => {
//     setSaving(true);
//     setTimeout(() => { setSaving(false); cb(); }, 900);
//   };

//   // ── Photo upload
//   const handlePhoto = (e) => {
//     const file = e.target.files[0];
//     if (!file) return;
//     if (file.size > 5 * 1024 * 1024) { showToast('error', 'File too large. Max 5MB.'); return; }
//     const reader = new FileReader();
//     reader.onload = ev => { setPhotoSrc(ev.target.result); showToast('success', 'Photo updated!'); };
//     reader.readAsDataURL(file);
//   };

//   // ── Save profile
//   const saveProfile = () => {
//     if (!profile.fullName.trim()) { showToast('error', 'Full name is required.'); return; }
//     if (!profile.username.trim()) { showToast('error', 'Username is required.'); return; }
//     simulate(() => {
//       setSaved({ ...profile });
//       setProfileDirty(false);
//       showToast('success', 'Profile saved successfully!');
//     });
//   };

//   const resetProfile = () => {
//     setProfile({ ...saved });
//     setProfileDirty(false);
//     showToast('success', 'Changes reset.');
//   };

//   // ── Change password
//   const changePassword = () => {
//     if (!curPwd)             { showToast('error', 'Current password is required.'); return; }
//     if (newPwd.length < 8)   { showToast('error', 'Password must be at least 8 characters.'); return; }
//     if (newPwd !== confirmPwd) { showToast('error', 'New passwords do not match.'); return; }
//     simulate(() => {
//       setCurPwd(''); setNewPwd(''); setConfirmPwd('');
//       showToast('success', 'Password changed successfully!');
//     });
//   };

//   // ── Save appearance
//   const saveAppearance = () => {
//     simulate(() => showToast('success', 'Appearance preferences saved!'));
//   };

//   // ── Save notifications
//   const saveNotifs = () => {
//     simulate(() => showToast('success', 'Notification preferences saved!'));
//   };

//   const initials = (profile.fullName || 'A').charAt(0).toUpperCase();

//   return (
//     <div className="st-root">
//       {/* ── Page Header */}
//       <div className="st-page-header">
//         <div className="st-page-header-text">
//           <h1 className="st-page-title">Settings</h1>
//           <p className="st-page-sub">Manage your profile, security, and preferences</p>
//         </div>
//         {tab === 'profile' && (
//           <div className="st-header-actions">
//             <button
//               className="st-btn st-btn-ghost"
//               onClick={resetProfile}
//               disabled={!profileDirty || saving}
//             >
//               Discard
//             </button>
//             <button
//               className={`st-btn st-btn-primary${saving ? ' loading' : ''}`}
//               onClick={saveProfile}
//               disabled={saving}
//             >
//               {saving ? <><IcLoader /> Saving…</> : <><IcSave /> Save Changes</>}
//             </button>
//           </div>
//         )}
//       </div>

//       {/* ── Toast */}
//       <div className="st-toast-area">
//         <Toast type={toast.type} msg={toast.msg} onClose={() => setToast({ type:'', msg:'' })} />
//       </div>

//       {/* ── Tab Nav */}
//       <div className="st-tab-nav">
//         {TABS.map(t => (
//           <button
//             key={t.id}
//             className={`st-tab-pill${tab === t.id ? ' active' : ''}`}
//             onClick={() => setTab(t.id)}
//           >
//             <span className="st-tab-pill-icon"><t.Icon /></span>
//             <span className="st-tab-pill-label">{t.label}</span>
//           </button>
//         ))}
//       </div>

//       {/* ══════════ PROFILE TAB ══════════ */}
//       {tab === 'profile' && (
//         <div className="st-tab-body">
//           {/* Photo card */}
//           <div className="st-card">
//             <div className="st-section-label">
//               <span className="st-section-icon"><IcCamera /></span>
//               <div>
//                 <div className="st-section-title">Profile Photo</div>
//                 <div className="st-section-sub">JPG or PNG, max 5 MB</div>
//               </div>
//             </div>
//             <div className="st-photo-row">
//               <div
//                 className="st-avatar-lg"
//                 onClick={() => fileRef.current.click()}
//                 title="Click to change photo"
//                 role="button"
//                 tabIndex={0}
//                 onKeyDown={e => e.key === 'Enter' && fileRef.current.click()}
//               >
//                 {photoSrc
//                   ? <img src={photoSrc} alt="Profile" />
//                   : <span className="st-avatar-initials">{initials}</span>
//                 }
//                 <div className="st-avatar-overlay">
//                   <IcCamera />
//                   <span className="st-avatar-overlay-text">Change</span>
//                 </div>
//               </div>
//               <input ref={fileRef} type="file" accept="image/*" style={{ display: 'none' }} onChange={handlePhoto} />
//               <div className="st-photo-meta">
//                 <div className="st-photo-name">{profile.fullName || 'Administrator'}</div>
//                 <div className="st-photo-role">{profile.role}</div>
//                 <div className="st-photo-actions">
//                   <label className="st-btn st-btn-outline st-btn-sm" style={{ cursor: 'pointer' }}>
//                     <IcCamera /> Upload Photo
//                     <input type="file" accept="image/*" style={{ display: 'none' }} onChange={handlePhoto} />
//                   </label>
//                   {photoSrc && (
//                     <button
//                       className="st-btn st-btn-danger st-btn-sm"
//                       onClick={() => { setPhotoSrc(null); showToast('success', 'Photo removed.'); }}
//                     >
//                       Remove
//                     </button>
//                   )}
//                 </div>
//               </div>
//             </div>
//           </div>

//           {/* Personal info card */}
//           <div className="st-card">
//             <div className="st-section-label">
//               <span className="st-section-icon"><IcUser /></span>
//               <div>
//                 <div className="st-section-title">Personal Information</div>
//                 <div className="st-section-sub">Update your name, contact, and role details</div>
//               </div>
//             </div>

//             <div className="st-form-grid">
//               <div className="st-field">
//                 <label htmlFor="fullName">Full Name <span className="req">*</span></label>
//                 <input
//                   id="fullName"
//                   type="text"
//                   value={profile.fullName}
//                   onChange={e => updateProfile('fullName', e.target.value)}
//                   placeholder="Your full name"
//                   className={!profile.fullName.trim() ? 'field-error' : ''}
//                 />
//                 {!profile.fullName.trim() && <span className="field-hint error">Full name is required</span>}
//               </div>
//               <div className="st-field">
//                 <label htmlFor="username">Username <span className="req">*</span></label>
//                 <input
//                   id="username"
//                   type="text"
//                   value={profile.username}
//                   onChange={e => updateProfile('username', e.target.value)}
//                   placeholder="username"
//                 />
//               </div>
//               <div className="st-field">
//                 <label htmlFor="email">Email Address</label>
//                 <input
//                   id="email"
//                   type="email"
//                   value={profile.email}
//                   onChange={e => updateProfile('email', e.target.value)}
//                   placeholder="email@example.com"
//                 />
//               </div>
//               <div className="st-field">
//                 <label htmlFor="phone">Phone Number</label>
//                 <input
//                   id="phone"
//                   type="tel"
//                   value={profile.phone}
//                   onChange={e => updateProfile('phone', e.target.value)}
//                   placeholder="+92 300 0000000"
//                 />
//               </div>
//               <div className="st-field">
//                 <label htmlFor="clinic">Clinic / Practice Name</label>
//                 <input
//                   id="clinic"
//                   type="text"
//                   value={profile.clinic}
//                   onChange={e => updateProfile('clinic', e.target.value)}
//                   placeholder="Clinic name"
//                 />
//               </div>
//               <div className="st-field">
//                 <label htmlFor="role">Role / Designation</label>
//                 <input
//                   id="role"
//                   type="text"
//                   value={profile.role}
//                   onChange={e => updateProfile('role', e.target.value)}
//                   placeholder="Your role"
//                 />
//               </div>
//             </div>

//             {profileDirty && (
//               <div className="st-dirty-banner">
//                 <IcAlert />
//                 <span>You have unsaved changes</span>
//                 <div className="st-dirty-actions">
//                   <button className="st-btn st-btn-ghost st-btn-sm" onClick={resetProfile}>Discard</button>
//                   <button
//                     className={`st-btn st-btn-primary st-btn-sm${saving ? ' loading' : ''}`}
//                     onClick={saveProfile}
//                     disabled={saving}
//                   >
//                     {saving ? 'Saving…' : 'Save'}
//                   </button>
//                 </div>
//               </div>
//             )}
//           </div>
//         </div>
//       )}

//       {/* ══════════ SECURITY TAB ══════════ */}
//       {tab === 'security' && (
//         <div className="st-tab-body">
//           {/* Change password */}
//           <div className="st-card">
//             <div className="st-section-label">
//               <span className="st-section-icon"><IcLock /></span>
//               <div>
//                 <div className="st-section-title">Change Password</div>
//                 <div className="st-section-sub">Use at least 8 characters with letters, numbers, and symbols</div>
//               </div>
//             </div>

//             <div className="st-pwd-stack">
//               <div className="st-field">
//                 <label htmlFor="curPwd">Current Password</label>
//                 <PwdInput id="curPwd" value={curPwd} onChange={e => setCurPwd(e.target.value)} placeholder="Enter current password" />
//               </div>
//               <div className="st-field">
//                 <label htmlFor="newPwd">New Password</label>
//                 <PwdInput id="newPwd" value={newPwd} onChange={e => setNewPwd(e.target.value)} placeholder="Enter new password" />
//                 {newPwd && (
//                   <div className="st-strength-wrap">
//                     <div className="st-strength-bar">
//                       <div className="st-strength-fill" style={{ width: strength.pct + '%', background: strength.color }} />
//                     </div>
//                     <span className="st-strength-label" style={{ color: strength.color }}>{strength.label}</span>
//                   </div>
//                 )}
//               </div>
//               <div className="st-field">
//                 <label htmlFor="confirmPwd">Confirm New Password</label>
//                 <PwdInput id="confirmPwd" value={confirmPwd} onChange={e => setConfirmPwd(e.target.value)} placeholder="Re-enter new password" />
//                 {confirmPwd && (
//                   <span
//                     className="st-match-label"
//                     style={{ color: newPwd === confirmPwd ? '#16a34a' : '#dc2626' }}
//                   >
//                     {newPwd === confirmPwd ? '✓ Passwords match' : '✗ Passwords do not match'}
//                   </span>
//                 )}
//               </div>
//             </div>

//             <div className="st-pwd-rules">
//               {[
//                 { ok: newPwd.length >= 8,              text: 'At least 8 characters'          },
//                 { ok: /[A-Z]/.test(newPwd),            text: 'One uppercase letter'            },
//                 { ok: /[0-9]/.test(newPwd),            text: 'One number'                     },
//                 { ok: /[^A-Za-z0-9]/.test(newPwd),    text: 'One special character'           },
//               ].map((r, i) => (
//                 <div key={i} className={`st-pwd-rule${r.ok ? ' met' : ''}`}>
//                   <span className="st-rule-dot" />
//                   {r.text}
//                 </div>
//               ))}
//             </div>

//             <button
//               className={`st-btn st-btn-primary${saving ? ' loading' : ''}`}
//               onClick={changePassword}
//               disabled={saving}
//               style={{ marginTop: 8 }}
//             >
//               {saving ? <><IcLoader /> Updating…</> : 'Update Password'}
//             </button>
//           </div>

//           {/* 2FA */}
//           <div className="st-card">
//             <div className="st-section-label">
//               <span className="st-section-icon"><IcShield /></span>
//               <div>
//                 <div className="st-section-title">Two-Factor Authentication</div>
//                 <div className="st-section-sub">Add an extra layer of security to your account</div>
//               </div>
//             </div>
//             <ToggleRow label="SMS Authentication"         desc="Receive a verification code via SMS on login"  checked={sms2fa}      onChange={setSms2fa} />
//             <ToggleRow label="Authenticator App"          desc="Use Google Authenticator or Authy"             checked={app2fa}      onChange={setApp2fa} />
//             <ToggleRow label="Email Verification on Login" desc="Send a code to your email on each sign-in"    checked={emailVerify} onChange={setEmailVerify} last />
//           </div>

//           {/* Danger zone */}
//           <div className="st-card st-card-danger">
//             <div className="st-section-title st-danger-title">Danger Zone</div>
//             <div className="st-section-sub" style={{ marginBottom: 16 }}>These actions are irreversible. Proceed with caution.</div>
//             <div className="st-danger-row">
//               <div>
//                 <div className="st-danger-label">Log out all sessions</div>
//                 <div className="st-danger-sub">Immediately sign out from every device</div>
//               </div>
//               <button className="st-btn st-btn-danger st-btn-sm" onClick={() => showToast('error', 'All other sessions terminated.')}>
//                 Log Out All
//               </button>
//             </div>
//             <div className="st-danger-row" style={{ borderBottom: 'none', marginBottom: 0, paddingBottom: 0 }}>
//               <div>
//                 <div className="st-danger-label" style={{ color: '#dc2626' }}>Delete Account</div>
//                 <div className="st-danger-sub">Permanently remove your account and all data</div>
//               </div>
//               <button className="st-btn st-btn-danger st-btn-sm" onClick={() => alert('This action requires superuser confirmation.')}>
//                 Delete Account
//               </button>
//             </div>
//           </div>
//         </div>
//       )}

//       {/* ══════════ APPEARANCE TAB ══════════ */}
//       {tab === 'appearance' && (
//         <div className="st-tab-body">
//           <div className="st-card">
//             <div className="st-section-label">
//               <span className="st-section-icon"><IcMoon /></span>
//               <div>
//                 <div className="st-section-title">Theme Mode</div>
//                 <div className="st-section-sub">Choose light or dark mode for the admin panel</div>
//               </div>
//             </div>

//             <div className="st-theme-grid">
//               {/* Light */}
//               <div
//                 className={`st-theme-card${!darkMode ? ' active' : ''}`}
//                 onClick={() => setDarkMode(false)}
//                 role="button"
//                 tabIndex={0}
//                 onKeyDown={e => e.key === 'Enter' && setDarkMode(false)}
//               >
//                 <div className="st-theme-preview st-theme-preview-light">
//                   <div className="tpv-sidebar" />
//                   <div className="tpv-body">
//                     <div className="tpv-bar" />
//                     <div className="tpv-card" />
//                     <div className="tpv-card tpv-card-short" />
//                   </div>
//                 </div>
//                 <div className="st-theme-footer">
//                   <span className="st-theme-icon-wrap light"><IcSun /></span>
//                   <div>
//                     <div className="st-theme-name">Light Mode</div>
//                     <div className="st-theme-desc">Clean white interface</div>
//                   </div>
//                   {!darkMode && <span className="st-theme-check">✓</span>}
//                 </div>
//               </div>

//               {/* Dark */}
//               <div
//                 className={`st-theme-card${darkMode ? ' active' : ''}`}
//                 onClick={() => setDarkMode(true)}
//                 role="button"
//                 tabIndex={0}
//                 onKeyDown={e => e.key === 'Enter' && setDarkMode(true)}
//               >
//                 <div className="st-theme-preview st-theme-preview-dark">
//                   <div className="tpv-sidebar dark" />
//                   <div className="tpv-body dark">
//                     <div className="tpv-bar dark" />
//                     <div className="tpv-card dark" />
//                     <div className="tpv-card dark tpv-card-short" />
//                   </div>
//                 </div>
//                 <div className="st-theme-footer">
//                   <span className="st-theme-icon-wrap dark"><IcMoon /></span>
//                   <div>
//                     <div className="st-theme-name">Dark Mode</div>
//                     <div className="st-theme-desc">Easy on the eyes</div>
//                   </div>
//                   {darkMode && <span className="st-theme-check">✓</span>}
//                 </div>
//               </div>
//             </div>

//             <div className="st-divider" />

//             <ToggleRow
//               label="Enable Dark Mode"
//               desc="Toggle between light and dark color schemes"
//               checked={darkMode}
//               onChange={setDarkMode}
//               last
//             />

//             <button
//               className={`st-btn st-btn-primary${saving ? ' loading' : ''}`}
//               onClick={saveAppearance}
//               disabled={saving}
//               style={{ marginTop: 20 }}
//             >
//               {saving ? <><IcLoader /> Saving…</> : <><IcSave /> Save Preferences</>}
//             </button>
//           </div>
//         </div>
//       )}

//       {/* ══════════ NOTIFICATIONS TAB ══════════ */}
//       {tab === 'notifications' && (
//         <div className="st-tab-body">
//           <div className="st-card">
//             <div className="st-section-label">
//               <span className="st-section-icon"><IcBell /></span>
//               <div>
//                 <div className="st-section-title">Email Notifications</div>
//                 <div className="st-section-sub">Receive emails for the events you care about</div>
//               </div>
//             </div>
//             <ToggleRow label="New Appointments"     desc="When a patient books an appointment"                checked={notifs.newAppointments} onChange={v => setNotifs(n => ({ ...n, newAppointments: v }))} />
//             <ToggleRow label="Appointment Reminders" desc="24-hour reminders before upcoming appointments"    checked={notifs.reminders}       onChange={v => setNotifs(n => ({ ...n, reminders:       v }))} />
//             <ToggleRow label="New Patient Reviews"  desc="When a patient submits a review"                    checked={notifs.reviews}         onChange={v => setNotifs(n => ({ ...n, reviews:         v }))} />
//             <ToggleRow label="Low Inventory Alerts" desc="When stock falls below minimum threshold"           checked={notifs.inventory}       onChange={v => setNotifs(n => ({ ...n, inventory:       v }))} />
//             <ToggleRow label="Weekly Financial Summary" desc="Weekly overview of revenue and expenses"        checked={notifs.reports}         onChange={v => setNotifs(n => ({ ...n, reports:         v }))} last />
//           </div>

//           <div className="st-card">
//             <div className="st-section-label">
//               <span className="st-section-icon"><IcBell /></span>
//               <div>
//                 <div className="st-section-title">In-App Notifications</div>
//                 <div className="st-section-sub">Control what appears in your notification panel</div>
//               </div>
//             </div>
//             <ToggleRow label="System Alerts"    desc="Critical system and security notifications"          checked={notifs.systemAlerts} onChange={v => setNotifs(n => ({ ...n, systemAlerts: v }))} />
//             <ToggleRow label="Staff Updates"    desc="Activity from employees and staff changes"           checked={notifs.staffUpdates} onChange={v => setNotifs(n => ({ ...n, staffUpdates: v }))} />
//             <ToggleRow label="Supplier Invoices" desc="Incoming invoices and delivery confirmations"       checked={notifs.invoices}     onChange={v => setNotifs(n => ({ ...n, invoices:     v }))} last />
//           </div>

//           <div className="st-card-actions">
//             <button
//               className={`st-btn st-btn-primary${saving ? ' loading' : ''}`}
//               onClick={saveNotifs}
//               disabled={saving}
//             >
//               {saving ? <><IcLoader /> Saving…</> : <><IcSave /> Save Preferences</>}
//             </button>
//             <button
//               className="st-btn st-btn-outline"
//               onClick={() => {
//                 setNotifs(n => Object.fromEntries(Object.keys(n).map(k => [k, true])));
//                 showToast('success', 'All notifications enabled!');
//               }}
//             >
//               Enable All
//             </button>
//             <button
//               className="st-btn st-btn-outline"
//               onClick={() => {
//                 setNotifs(n => Object.fromEntries(Object.keys(n).map(k => [k, false])));
//                 showToast('success', 'All notifications disabled.');
//               }}
//             >
//               Disable All
//             </button>
//           </div>
//         </div>
//       )}
//     </div>
//   );
// }











import React, { useState, useRef, useEffect } from 'react';
import { useTheme } from '../ThemeContext';
import './Settings.css';

const API = "http://127.0.0.1:8000";
// const getToken = () => localStorage.getItem("dt-token") || "";
// const authHeaders = () => {
//   const t = getToken();
//   return {
//     "Content-Type": "application/json",
//     ...(t ? { Authorization: `Token ${t}` } : {}),
//   };
// };
// const authHeaders = () => ({
//   "Content-Type": "application/json",
// });

headers: { "Content-Type"; "application/json" }
credentials: "include"
//  ── Icons ─────────────────────────────────────────────────────────────────
const IcUser   = () => <svg viewBox="0 0 20 20" fill="none"><circle cx="10" cy="7" r="3.5" stroke="currentColor" strokeWidth="1.5"/><path d="M2.5 18c0-3.87 3.36-6.5 7.5-6.5s7.5 2.63 7.5 6.5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/></svg>;
const IcShield = () => <svg viewBox="0 0 20 20" fill="none"><path d="M10 2l6 2.5v5c0 3.5-2.5 6.5-6 8-3.5-1.5-6-4.5-6-8v-5L10 2z" stroke="currentColor" strokeWidth="1.5" strokeLinejoin="round"/></svg>;
const IcBell   = () => <svg viewBox="0 0 20 20" fill="none"><path d="M10 2.5A5.5 5.5 0 004.5 8v3.5L3 13h14l-1.5-1.5V8A5.5 5.5 0 0010 2.5z" stroke="currentColor" strokeWidth="1.5" strokeLinejoin="round"/><path d="M8 13v.5a2 2 0 004 0V13" stroke="currentColor" strokeWidth="1.3"/></svg>;
const IcMoon   = () => <svg viewBox="0 0 20 20" fill="none"><path d="M17.5 11.5A7.5 7.5 0 018.5 2.5a7.5 7.5 0 100 15 7.5 7.5 0 009-6z" stroke="currentColor" strokeWidth="1.5" strokeLinejoin="round"/></svg>;
const IcLock   = () => <svg viewBox="0 0 20 20" fill="none"><rect x="4" y="9" width="12" height="9" rx="2" stroke="currentColor" strokeWidth="1.5"/><path d="M7 9V7a3 3 0 016 0v2" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/></svg>;
const IcCamera = () => <svg viewBox="0 0 20 20" fill="none"><path d="M2 6.5A1.5 1.5 0 013.5 5h1.2L6 3h8l1.3 2h1.2A1.5 1.5 0 0118 6.5v9A1.5 1.5 0 0116.5 17h-13A1.5 1.5 0 012 15.5v-9z" stroke="currentColor" strokeWidth="1.5"/><circle cx="10" cy="11" r="2.5" stroke="currentColor" strokeWidth="1.3"/></svg>;
const IcCheck  = () => <svg viewBox="0 0 20 20" fill="none"><circle cx="10" cy="10" r="8" stroke="currentColor" strokeWidth="1.5"/><path d="M6.5 10l2.5 2.5 4-4" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/></svg>;
const IcAlert  = () => <svg viewBox="0 0 20 20" fill="none"><circle cx="10" cy="10" r="8" stroke="currentColor" strokeWidth="1.5"/><path d="M10 7v3M10 13h.01" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/></svg>;
const IcEye    = () => <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>;
const IcEyeOff = () => <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M17.94 17.94A10.07 10.07 0 0112 20c-7 0-11-8-11-8a18.45 18.45 0 015.06-5.94M9.9 4.24A9.12 9.12 0 0112 4c7 0 11 8 11 8a18.5 18.5 0 01-2.16 3.19m-6.72-1.07a3 3 0 11-4.24-4.24"/><line x1="1" y1="1" x2="23" y2="23"/></svg>;
const IcSun    = () => <svg viewBox="0 0 20 20" fill="none"><circle cx="10" cy="10" r="3.5" stroke="currentColor" strokeWidth="1.5"/><path d="M10 2v2M10 16v2M2 10h2M16 10h2M4.22 4.22l1.42 1.42M14.36 14.36l1.42 1.42M4.22 15.78l1.42-1.42M14.36 5.64l1.42-1.42" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/></svg>;
const IcSave   = () => <svg viewBox="0 0 20 20" fill="none"><path d="M3 4a1 1 0 011-1h9l4 4v9a1 1 0 01-1 1H4a1 1 0 01-1-1V4z" stroke="currentColor" strokeWidth="1.5" strokeLinejoin="round"/><path d="M7 3v4h6V3M7 13h6" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round"/></svg>;
const IcLoader = () => <svg viewBox="0 0 20 20" fill="none" className="spin-icon"><circle cx="10" cy="10" r="7" stroke="currentColor" strokeWidth="1.5" strokeDasharray="30" strokeDashoffset="10"/></svg>;

// ── Helpers ───────────────────────────────────────────────────────────────
function Toggle({ checked, onChange }) {
  return (
    <label className="st-toggle">
      <input type="checkbox" checked={checked} onChange={e => onChange(e.target.checked)} />
      <span className="st-slider" />
    </label>
  );
}

function ToggleRow({ label, desc, checked, onChange, last }) {
  return (
    <div className={`st-toggle-row${last ? ' last' : ''}`}>
      <div className="st-toggle-info">
        <strong>{label}</strong>
        {desc && <span>{desc}</span>}
      </div>
      <Toggle checked={checked} onChange={onChange} />
    </div>
  );
}

function Toast({ type, msg, onClose }) {
  if (!msg) return null;
  return (
    <div className={`st-toast st-toast-${type}`}>
      <span className="st-toast-icon">{type === 'success' ? <IcCheck /> : <IcAlert />}</span>
      <span className="st-toast-msg">{msg}</span>
      <button className="st-toast-close" onClick={onClose}>✕</button>
    </div>
  );
}

function PwdInput({ value, onChange, placeholder, id }) {
  const [show, setShow] = useState(false);
  return (
    <div className="st-pwd-wrap">
      <input
        id={id}
        type={show ? 'text' : 'password'}
        value={value}
        onChange={onChange}
        placeholder={placeholder}
        autoComplete="new-password"
      />
      <button type="button" className="st-eye-btn"
        onClick={() => setShow(s => !s)}
        aria-label={show ? 'Hide password' : 'Show password'}
      >
        {show ? <IcEyeOff /> : <IcEye />}
      </button>
    </div>
  );
}

function getStrength(pwd) {
  if (!pwd) return { pct: 0, label: '', color: '' };
  let s = 0;
  if (pwd.length >= 8) s++;
  if (/[A-Z]/.test(pwd)) s++;
  if (/[0-9]/.test(pwd)) s++;
  if (/[^A-Za-z0-9]/.test(pwd)) s++;
  return [
    { pct: 15, label: 'Too short',  color: '#ef4444' },
    { pct: 35, label: 'Weak',       color: '#f97316' },
    { pct: 60, label: 'Fair',       color: '#eab308' },
    { pct: 80, label: 'Good',       color: '#22c55e' },
    { pct: 100, label: 'Strong',    color: '#16a34a' },
  ][Math.min(s, 4)];
}

const TABS = [
  { id: 'profile',       label: 'Profile',       Icon: IcUser   },
  { id: 'security',      label: 'Security',      Icon: IcShield },
  { id: 'appearance',    label: 'Appearance',    Icon: IcMoon   },
  { id: 'notifications', label: 'Notifications', Icon: IcBell   },
];

// ════════════════════════════════════════════════════════════════════════════
//  SETTINGS COMPONENT
// ════════════════════════════════════════════════════════════════════════════
export default function Settings({ user, apiBase = API, onProfileUpdate }) {
  const { dark, setDark } = useTheme();
  const [tab, setTab]       = useState('profile');
  const [toast, setToast]   = useState({ type: '', msg: '' });
  const [saving, setSaving] = useState(false);
  const fileRef             = useRef();

  // ── Profile state — initialised from `user` prop ──────────────────────
  const makeProfile = (u) => ({
    fullName:  u?.full_name  || u?.username || 'Administrator',
    username:  u?.username   || 'admin',
    email:     u?.email      || '',
    phone:     u?.phone      || '',
    clinic:    u?.clinic     || 'Dentistree Clinic',
    role:      u?.is_superuser ? 'Super Admin' : (u?.role || 'User'),
  });

  const [profile, setProfile]           = useState(() => makeProfile(user));
  const [savedProfile, setSavedProfile] = useState(() => makeProfile(user));
  const [photoSrc, setPhotoSrc]         = useState(user?.photo || null);
  const [profileDirty, setProfileDirty] = useState(false);

  // Sync if parent `user` prop changes (e.g. after login)
  useEffect(() => {
    if (user) {
      const p = makeProfile(user);
      setProfile(p);
      setSavedProfile(p);
      setPhotoSrc(user.photo || null);
    }
  }, [user]);

  const updateField = (key, val) => {
    setProfile(p => ({ ...p, [key]: val }));
    setProfileDirty(true);
  };

  // ── Password ──────────────────────────────────────────────────────────
  const [curPwd,     setCurPwd]     = useState('');
  const [newPwd,     setNewPwd]     = useState('');
  const [confirmPwd, setConfirmPwd] = useState('');
  const strength = getStrength(newPwd);

  // ── Notifications ─────────────────────────────────────────────────────
  const [notifs, setNotifs] = useState({
    newAppointments: true, reminders: true, reviews: false,
    inventory: true, reports: false,
    systemAlerts: true, staffUpdates: false, invoices: true,
  });

  // ── 2FA ───────────────────────────────────────────────────────────────
  const [sms2fa,      setSms2fa]      = useState(false);
  const [app2fa,      setApp2fa]      = useState(true);
  const [emailVerify, setEmailVerify] = useState(false);

  // ── Toast helpers ─────────────────────────────────────────────────────
  const showToast = (type, msg) => {
    setToast({ type, msg });
    setTimeout(() => setToast({ type: '', msg: '' }), 3500);
  };

  // ── Photo upload ──────────────────────────────────────────────────────
  const handlePhoto = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    if (file.size > 5 * 1024 * 1024) { showToast('error', 'File too large. Max 5 MB.'); return; }
    const reader = new FileReader();
    reader.onload = ev => {
      setPhotoSrc(ev.target.result);
      showToast('success', 'Photo selected — save profile to apply.');
    };
    reader.readAsDataURL(file);
  };

  // ════════════════════════════════════════════════════════════════════════
  //  SAVE PROFILE — Real API call to Django
  // ════════════════════════════════════════════════════════════════════════
  const saveProfile = async () => {
    if (!profile.fullName.trim()) { showToast('error', 'Full name is required.'); return; }
    if (!profile.username.trim()) { showToast('error', 'Username is required.'); return; }

    setSaving(true);
    try {
      const userId = user?.id || 1;
      const payload = {
        full_name:    profile.fullName,
        username:     profile.username,
        email:        profile.email,
        phone:        profile.phone,
        clinic:       profile.clinic,
        role:         profile.role,
        ...(photoSrc && photoSrc.startsWith('data:') ? { photo: photoSrc } : {}),
      };

      const res = await fetch(`${apiBase}/settings/update-profile/`, {
        method: "POST",
        headers: authHeaders(),
        credentials: "include",
        body: JSON.stringify(payload),
      });

      if (res.ok) {
        const data = await res.json();
        // ── Update parent App state so sidebar etc refresh instantly
        const updatedUser = {
          ...user,
          full_name: profile.fullName,
          username:  profile.username,
          email:     profile.email,
          phone:     profile.phone,
          clinic:    profile.clinic,
          role:      profile.role,
          photo:     photoSrc,
          ...(data.user || data),
        };
        setSavedProfile({ ...profile });
        setProfileDirty(false);
        onProfileUpdate?.(updatedUser);
        showToast('success', 'Profile saved and updated successfully!');
      } else {
        let msg = 'Failed to save profile.';
        try { const e = await res.json(); msg = e.detail || e.error || msg; } catch {}
        showToast('error', msg);
      }
    } catch {
      // ── Offline / backend unreachable: update frontend only
      const updatedUser = {
        ...user,
        full_name: profile.fullName,
        username:  profile.username,
        email:     profile.email,
        phone:     profile.phone,
        clinic:    profile.clinic,
        photo:     photoSrc,
        role:      profile.role,
      };
      setSavedProfile({ ...profile });
      setProfileDirty(false);
      onProfileUpdate?.(updatedUser);
      showToast('success', 'Profile updated locally (server offline).');
    } finally {
      setSaving(false);
    }
  };

  const resetProfile = () => {
    setProfile({ ...savedProfile });
    setProfileDirty(false);
    showToast('success', 'Changes discarded.');
  };

  // ════════════════════════════════════════════════════════════════════════
  //  CHANGE PASSWORD — Real API call
  // ════════════════════════════════════════════════════════════════════════
  const changePassword = async () => {
    if (!curPwd)              { showToast('error', 'Current password is required.'); return; }
    if (newPwd.length < 8)    { showToast('error', 'New password must be at least 8 characters.'); return; }
    if (newPwd !== confirmPwd){ showToast('error', 'Passwords do not match.'); return; }

    setSaving(true);
    try {
      const res = await fetch(`${apiBase}/auth/change-password/`, {
        method: "POST",
        headers: authHeaders(),
        credentials: "include",
        body: JSON.stringify({
          current_password: curPwd,
          new_password:     newPwd,
          confirm_password: confirmPwd,
        }),
      });

      if (res.ok) {
        setCurPwd(''); setNewPwd(''); setConfirmPwd('');
        showToast('success', 'Password changed successfully!');
      } else {
        let msg = 'Failed to change password.';
        try { const e = await res.json(); msg = e.detail || e.error || msg; } catch {}
        showToast('error', msg);
      }
    } catch {
      showToast('error', 'Cannot reach server. Please try again later.');
    } finally {
      setSaving(false);
    }
  };

  // ── Appearance ────────────────────────────────────────────────────────
  const saveAppearance = () => {
    showToast('success', `${dark ? 'Dark' : 'Light'} mode saved!`);
  };

  // ── Notifications ─────────────────────────────────────────────────────
  const saveNotifs = () => {
    showToast('success', 'Notification preferences saved!');
  };

  const initials = (profile.fullName || 'A').charAt(0).toUpperCase();

  // ════════════════════════════════════════════════════════════════════════
  //  RENDER
  // ════════════════════════════════════════════════════════════════════════
  return (
    <div className="st-root">

      {/* Page Header */}
      <div className="st-page-header">
        <div>
          <h1 className="st-page-title">Settings</h1>
          <p className="st-page-sub">Manage your profile, security, and preferences</p>
        </div>
        {tab === 'profile' && (
          <div className="st-header-actions">
            <button className="st-btn st-btn-ghost"
              onClick={resetProfile} disabled={!profileDirty || saving}>
              Discard
            </button>
            <button
              className={`st-btn st-btn-primary${saving ? ' loading' : ''}`}
              onClick={saveProfile} disabled={saving}>
              {saving ? <><IcLoader /> Saving…</> : <><IcSave /> Save Changes</>}
            </button>
          </div>
        )}
      </div>

      {/* Toast */}
      <div className="st-toast-area">
        <Toast type={toast.type} msg={toast.msg} onClose={() => setToast({ type:'', msg:'' })} />
      </div>

      {/* Tab Nav */}
      <div className="st-tab-nav">
        {TABS.map(t => (
          <button key={t.id}
            className={`st-tab-pill${tab === t.id ? ' active' : ''}`}
            onClick={() => { setTab(t.id); setToast({ type:'', msg:'' }); }}>
            <span className="st-tab-pill-icon"><t.Icon /></span>
            <span className="st-tab-pill-label">{t.label}</span>
          </button>
        ))}
      </div>

      {/* ══ PROFILE ══════════════════════════════════════════════════════ */}
      {tab === 'profile' && (
        <div className="st-tab-body">

          {/* Photo */}
          <div className="st-card">
            <div className="st-section-label">
              <span className="st-section-icon"><IcCamera /></span>
              <div>
                <div className="st-section-title">Profile Photo</div>
                <div className="st-section-sub">JPG or PNG, max 5 MB</div>
              </div>
            </div>
            <div className="st-photo-row">
              <div className="st-avatar-lg"
                onClick={() => fileRef.current.click()}
                role="button" tabIndex={0}
                onKeyDown={e => e.key === 'Enter' && fileRef.current.click()}>
                {photoSrc
                  ? <img src={photoSrc} alt="Profile" />
                  : <span className="st-avatar-initials">{initials}</span>
                }
                <div className="st-avatar-overlay">
                  <IcCamera />
                  <span className="st-avatar-overlay-text">Change</span>
                </div>
              </div>
              <input ref={fileRef} type="file" accept="image/*"
                style={{ display: 'none' }} onChange={handlePhoto} />
              <div className="st-photo-meta">
                <div className="st-photo-name">{profile.fullName}</div>
                <div className="st-photo-role">{profile.role}</div>
                <div className="st-photo-actions">
                  <label className="st-btn st-btn-outline st-btn-sm" style={{ cursor: 'pointer' }}>
                    <IcCamera /> Upload Photo
                    <input type="file" accept="image/*"
                      style={{ display: 'none' }} onChange={handlePhoto} />
                  </label>
                  {photoSrc && (
                    <button className="st-btn st-btn-danger st-btn-sm"
                      onClick={() => { setPhotoSrc(null); showToast('success', 'Photo removed.'); }}>
                      Remove
                    </button>
                  )}
                </div>
              </div>
            </div>
          </div>

          {/* Personal Info */}
          <div className="st-card">
            <div className="st-section-label">
              <span className="st-section-icon"><IcUser /></span>
              <div>
                <div className="st-section-title">Personal Information</div>
                <div className="st-section-sub">
                  Updates are saved to the database and reflected immediately everywhere
                </div>
              </div>
            </div>

            <div className="st-form-grid">
              <div className="st-field">
                <label htmlFor="st-fullName">Full Name <span className="req">*</span></label>
                <input id="st-fullName" type="text" value={profile.fullName}
                  onChange={e => updateField('fullName', e.target.value)}
                  placeholder="Your full name"
                  className={!profile.fullName.trim() ? 'field-error' : ''} />
                {!profile.fullName.trim() && <span className="field-hint error">Required</span>}
              </div>
              <div className="st-field">
                <label htmlFor="st-username">Username <span className="req">*</span></label>
                <input id="st-username" type="text" value={profile.username}
                  onChange={e => updateField('username', e.target.value)}
                  placeholder="username" />
              </div>
              <div className="st-field">
                <label htmlFor="st-email">Email Address</label>
                <input id="st-email" type="email" value={profile.email}
                  onChange={e => updateField('email', e.target.value)}
                  placeholder="email@example.com" />
              </div>
              <div className="st-field">
                <label htmlFor="st-phone">Phone Number</label>
                <input id="st-phone" type="tel" value={profile.phone}
                  onChange={e => updateField('phone', e.target.value)}
                  placeholder="+92 300 0000000" />
              </div>
              <div className="st-field">
                <label htmlFor="st-clinic">Clinic Name</label>
                <input id="st-clinic" type="text" value={profile.clinic}
                  onChange={e => updateField('clinic', e.target.value)}
                  placeholder="Clinic name" />
              </div>
              <div className="st-field">
                <label htmlFor="st-role">Role / Designation</label>
                <input id="st-role" type="text" value={profile.role}
                  onChange={e => updateField('role', e.target.value)}
                  placeholder="Your role" />
              </div>
            </div>

            {profileDirty && (
              <div className="st-dirty-banner">
                <IcAlert />
                <span>You have unsaved changes</span>
                <div className="st-dirty-actions">
                  <button className="st-btn st-btn-ghost st-btn-sm" onClick={resetProfile}>
                    Discard
                  </button>
                  <button
                    className={`st-btn st-btn-primary st-btn-sm${saving ? ' loading' : ''}`}
                    onClick={saveProfile} disabled={saving}>
                    {saving ? 'Saving…' : 'Save'}
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* ══ SECURITY ════════════════════════════════════════════════════ */}
      {tab === 'security' && (
        <div className="st-tab-body">
          <div className="st-card">
            <div className="st-section-label">
              <span className="st-section-icon"><IcLock /></span>
              <div>
                <div className="st-section-title">Change Password</div>
                <div className="st-section-sub">At least 8 characters with letters, numbers, and symbols</div>
              </div>
            </div>
            <div className="st-pwd-stack">
              <div className="st-field">
                <label htmlFor="curPwd">Current Password</label>
                <PwdInput id="curPwd" value={curPwd}
                  onChange={e => setCurPwd(e.target.value)} placeholder="Current password" />
              </div>
              <div className="st-field">
                <label htmlFor="newPwd">New Password</label>
                <PwdInput id="newPwd" value={newPwd}
                  onChange={e => setNewPwd(e.target.value)} placeholder="New password" />
                {newPwd && (
                  <div className="st-strength-wrap">
                    <div className="st-strength-bar">
                      <div className="st-strength-fill"
                        style={{ width: strength.pct+'%', background: strength.color }} />
                    </div>
                    <span className="st-strength-label" style={{ color: strength.color }}>
                      {strength.label}
                    </span>
                  </div>
                )}
              </div>
              <div className="st-field">
                <label htmlFor="confirmPwd">Confirm New Password</label>
                <PwdInput id="confirmPwd" value={confirmPwd}
                  onChange={e => setConfirmPwd(e.target.value)} placeholder="Confirm new password" />
                {confirmPwd && (
                  <span className="st-match-label"
                    style={{ color: newPwd === confirmPwd ? '#16a34a' : '#dc2626' }}>
                    {newPwd === confirmPwd ? '✓ Passwords match' : '✗ Do not match'}
                  </span>
                )}
              </div>
            </div>
            <div className="st-pwd-rules">
              {[
                { ok: newPwd.length >= 8,           text: 'At least 8 characters' },
                { ok: /[A-Z]/.test(newPwd),         text: 'One uppercase letter'  },
                { ok: /[0-9]/.test(newPwd),         text: 'One number'            },
                { ok: /[^A-Za-z0-9]/.test(newPwd),  text: 'One special character' },
              ].map((r, i) => (
                <div key={i} className={`st-pwd-rule${r.ok ? ' met' : ''}`}>
                  <span className="st-rule-dot" />{r.text}
                </div>
              ))}
            </div>
            <button
              className={`st-btn st-btn-primary${saving ? ' loading' : ''}`}
              onClick={changePassword} disabled={saving} style={{ marginTop: 8 }}>
              {saving ? <><IcLoader /> Updating…</> : 'Update Password'}
            </button>
          </div>

          <div className="st-card">
            <div className="st-section-label">
              <span className="st-section-icon"><IcShield /></span>
              <div>
                <div className="st-section-title">Two-Factor Authentication</div>
                <div className="st-section-sub">Add an extra layer of security</div>
              </div>
            </div>
            <ToggleRow label="SMS Authentication"
              desc="Receive a code via SMS on login" checked={sms2fa} onChange={setSms2fa} />
            <ToggleRow label="Authenticator App"
              desc="Use Google Authenticator or Authy" checked={app2fa} onChange={setApp2fa} />
            <ToggleRow label="Email Verification"
              desc="Send a code to your email on each sign-in"
              checked={emailVerify} onChange={setEmailVerify} last />
          </div>

          <div className="st-card st-card-danger">
            <div className="st-section-title st-danger-title">Danger Zone</div>
            <div className="st-section-sub" style={{ marginBottom: 16 }}>
              Irreversible actions — proceed with caution.
            </div>
            <div className="st-danger-row">
              <div>
                <div className="st-danger-label">Log out all sessions</div>
                <div className="st-danger-sub">Sign out from every device immediately</div>
              </div>
              <button className="st-btn st-btn-danger st-btn-sm"
                onClick={() => showToast('error', 'All sessions terminated.')}>
                Log Out All
              </button>
            </div>
            <div className="st-danger-row" style={{ borderBottom:'none', paddingBottom:0 }}>
              <div>
                <div className="st-danger-label" style={{ color:'#dc2626' }}>Delete Account</div>
                <div className="st-danger-sub">Permanently remove account and all data</div>
              </div>
              <button className="st-btn st-btn-danger st-btn-sm"
                onClick={() => alert('Requires superuser confirmation.')}>
                Delete Account
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ══ APPEARANCE ══════════════════════════════════════════════════ */}
      {tab === 'appearance' && (
        <div className="st-tab-body">
          <div className="st-card">
            <div className="st-section-label">
              <span className="st-section-icon"><IcMoon /></span>
              <div>
                <div className="st-section-title">Theme Mode</div>
                <div className="st-section-sub">
                  Switching immediately applies across the entire application
                </div>
              </div>
            </div>

            <div className="st-theme-grid">
              <div
                className={`st-theme-card${!dark ? ' active' : ''}`}
                onClick={() => setDark(false)}
                role="button" tabIndex={0}
                onKeyDown={e => e.key === 'Enter' && setDark(false)}>
                <div className="st-theme-preview st-theme-preview-light">
                  <div className="tpv-sidebar" />
                  <div className="tpv-body">
                    <div className="tpv-bar" />
                    <div className="tpv-card" />
                    <div className="tpv-card tpv-card-short" />
                  </div>
                </div>
                <div className="st-theme-footer">
                  <span className="st-theme-icon-wrap light"><IcSun /></span>
                  <div>
                    <div className="st-theme-name">Light Mode</div>
                    <div className="st-theme-desc">Clean white interface</div>
                  </div>
                  {!dark && <span className="st-theme-check">✓</span>}
                </div>
              </div>

              <div
                className={`st-theme-card${dark ? ' active' : ''}`}
                onClick={() => setDark(true)}
                role="button" tabIndex={0}
                onKeyDown={e => e.key === 'Enter' && setDark(true)}>
                <div className="st-theme-preview st-theme-preview-dark">
                  <div className="tpv-sidebar dark" />
                  <div className="tpv-body dark">
                    <div className="tpv-bar dark" />
                    <div className="tpv-card dark" />
                    <div className="tpv-card dark tpv-card-short" />
                  </div>
                </div>
                <div className="st-theme-footer">
                  <span className="st-theme-icon-wrap dark"><IcMoon /></span>
                  <div>
                    <div className="st-theme-name">Dark Mode</div>
                    <div className="st-theme-desc">Easy on the eyes</div>
                  </div>
                  {dark && <span className="st-theme-check">✓</span>}
                </div>
              </div>
            </div>

            <div className="st-divider" />
            <ToggleRow
              label="Enable Dark Mode"
              desc="Applies globally — sidebar, tables, modals, inputs, all pages"
              checked={dark} onChange={setDark} last />

            <button
              className={`st-btn st-btn-primary${saving ? ' loading' : ''}`}
              onClick={saveAppearance} disabled={saving} style={{ marginTop: 20 }}>
              {saving ? <><IcLoader /> Saving…</> : <><IcSave /> Save Preferences</>}
            </button>
          </div>
        </div>
      )}

      {/* ══ NOTIFICATIONS ═══════════════════════════════════════════════ */}
      {tab === 'notifications' && (
        <div className="st-tab-body">
          <div className="st-card">
            <div className="st-section-label">
              <span className="st-section-icon"><IcBell /></span>
              <div>
                <div className="st-section-title">Email Notifications</div>
                <div className="st-section-sub">Receive emails for the events you care about</div>
              </div>
            </div>
            <ToggleRow label="New Appointments"    desc="When a patient books"              checked={notifs.newAppointments} onChange={v => setNotifs(n=>({...n,newAppointments:v}))} />
            <ToggleRow label="Appointment Reminders" desc="24-hour before reminders"       checked={notifs.reminders}       onChange={v => setNotifs(n=>({...n,reminders:v}))} />
            <ToggleRow label="New Patient Reviews" desc="When a patient submits a review"  checked={notifs.reviews}         onChange={v => setNotifs(n=>({...n,reviews:v}))} />
            <ToggleRow label="Low Inventory"       desc="Stock below minimum threshold"    checked={notifs.inventory}       onChange={v => setNotifs(n=>({...n,inventory:v}))} />
            <ToggleRow label="Weekly Financial"    desc="Weekly revenue & expense summary" checked={notifs.reports}         onChange={v => setNotifs(n=>({...n,reports:v}))} last />
          </div>
          <div className="st-card">
            <div className="st-section-label">
              <span className="st-section-icon"><IcBell /></span>
              <div>
                <div className="st-section-title">In-App Notifications</div>
                <div className="st-section-sub">Control what appears in your panel</div>
              </div>
            </div>
            <ToggleRow label="System Alerts"     desc="Critical system and security alerts"  checked={notifs.systemAlerts} onChange={v => setNotifs(n=>({...n,systemAlerts:v}))} />
            <ToggleRow label="Staff Updates"     desc="Employee and staff activity changes"  checked={notifs.staffUpdates} onChange={v => setNotifs(n=>({...n,staffUpdates:v}))} />
            <ToggleRow label="Supplier Invoices" desc="Incoming invoices and deliveries"     checked={notifs.invoices}     onChange={v => setNotifs(n=>({...n,invoices:v}))} last />
          </div>
          <div className="st-card-actions">
            <button className={`st-btn st-btn-primary${saving?' loading':''}`}
              onClick={saveNotifs} disabled={saving}>
              {saving ? <><IcLoader /> Saving…</> : <><IcSave /> Save Preferences</>}
            </button>
            <button className="st-btn st-btn-outline"
              onClick={() => { setNotifs(n=>Object.fromEntries(Object.keys(n).map(k=>[k,true]))); showToast('success','All enabled!'); }}>
              Enable All
            </button>
            <button className="st-btn st-btn-outline"
              onClick={() => { setNotifs(n=>Object.fromEntries(Object.keys(n).map(k=>[k,false]))); showToast('success','All disabled.'); }}>
              Disable All
            </button>
          </div>
        </div>
      )}
    </div>
  );
}