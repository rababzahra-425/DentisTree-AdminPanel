// import React, { useEffect, useState } from "react";
// import {
//   BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, 
//   ResponsiveContainer, Cell, AreaChart, Area 
// } from "recharts";
// import "./Dashboard.css";

// const fmt = (n) => `Rs. ${Number(n || 0).toLocaleString()}`;

// const STATUS_COLOR = {
//   Pending:   { bg: "#f39c1220", text: "#f39c12", dot: "#f39c12" },
//   Approved:  { bg: "#2ecc7120", text: "#2ecc71", dot: "#2ecc71" },
//   Completed: { bg: "#3498db20", text: "#3498db", dot: "#3498db" },
//   Cancelled: { bg: "#e74c3c20", text: "#e74c3c", dot: "#e74c3c" },
// };

// const STAT_CARDS = [
//   { key: "total_patients",    label: "Total Patients",        icon: "👥", accent: "#3498db" },
//   { key: "today_appointments",    label: "Today's Appointments",  icon: "📅", accent: "#2ecc71" },
//   { key: "total_employees",       label: "Active Employees",      icon: "👤", accent: "#3498db" },
// ];

// const CustomBarTooltip = ({ active, payload, label }) => {
//   if (!active || !payload?.length) return null;
//   return (
//     <div className="db-tooltip">
//       <p className="db-tooltip-label">{payload[0]?.payload?.date || label}</p>
//       <p className="db-tooltip-val">{fmt(payload[0]?.value)}</p>
//     </div>
//   );
// };

// function StarRating({ rating }) {
//   return (
//     <span className="db-stars">
//       {[1, 2, 3, 4, 5].map(i => (
//         <span key={i} className={i <= rating ? "db-star on" : "db-star off"}>★</span>
//       ))}
//     </span>
//   );
// }

// function Dashboard() {
//   const [data, setData] = useState(null);
//   const [loading, setLoading] = useState(true);
//   const [time, setTime] = useState(new Date());

//   useEffect(() => {
//     refresh();
//     const tick = setInterval(() => setTime(new Date()), 1000);
//     return () => clearInterval(tick);
//   }, []);

//   const refresh = () => {
//     setLoading(true);
//     fetch("http://127.0.0.1:8000/dashboard/")
//       .then(r => r.json())
//       .then(d => { setData(d); setLoading(false); })
//       .catch(() => setLoading(false));
//   };

//   const stats = data?.stats || {};
//   const recentAppts = data?.recent_appointments || [];
//   const recentReviews = data?.recent_reviews || [];
//   const lowStock = data?.low_stock_items || [];
//   const chartData = data?.revenue_chart || [];
//   const maxRevenue = Math.max(...chartData.map(d => d.revenue), 1);

//   return (
//     <div className="db-container">
//       {/* ── Top Bar ── */}
//       <div className="db-topbar">
//         <div className="db-topbar-left">
//           <h1 className="db-title">Dashboard</h1>
//         </div>
//         <div className="db-topbar-right">
//           <div className="db-clock">
//             <span className="db-clock-time">
//               {time.toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit", second: "2-digit" })}
//             </span>
//             <span className="db-clock-date">
//               {time.toLocaleDateString("en-US", { weekday: "long", month: "long", day: "numeric", year: "numeric" })}
//             </span>
//           </div>
//           <button className="db-refresh-btn" onClick={refresh}>↻ Refresh</button>
//         </div>
//       </div>

//       {loading ? (
//         <div className="db-loading">
//           <div className="db-spinner" />
//           <span>Loading dashboard...</span>
//         </div>
//       ) : (
//         <>
//           {/* ── Stat Cards ── */}
//           <div className="db-stats-grid">
//             {STAT_CARDS.map((card) => (
//               <div className="db-stat-card" key={card.key} style={{ "--accent": card.accent }}>
//                 <div className="db-stat-icon">{card.icon}</div>
//                 <div className="db-stat-body">
//                   <span className="db-stat-value">{stats[card.key] ?? 0}</span>
//                   <span className="db-stat-label">{card.label}</span>
//                 </div>
//                 <div className="db-stat-glow" />
//               </div>
//             ))}
//             <div className="db-stat-card" style={{ "--accent": "#f1c40f" }}>
//               <div className="db-stat-icon">⭐</div>
//               <div className="db-stat-body">
//                 <span className="db-stat-value">{stats.avg_rating ?? "—"}<span className="db-stat-unit">/5</span></span>
//                 <span className="db-stat-label">Average Rating</span>
//               </div>
//               <div className="db-stat-glow" />
//             </div>
//           </div>

//           {/* ── NEW: Smooth Financial Overview Chart ── */}
//           <div className="db-widget db-finance-overview" style={{ marginBottom: "20px" }}>
//             <div className="db-widget-header">
//               <div>
//                 <h3>Financial Overview</h3>
//                 <span className="db-widget-sub">Monthly Income vs Expenses (Smooth Trend)</span>
//               </div>
//             </div>
//             <ResponsiveContainer width="100%" height={250}>
//               <AreaChart data={data?.financial_comparison || []} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
//                 <defs>
//                   <linearGradient id="colorIncome" x1="0" y1="0" x2="0" y2="1">
//                     <stop offset="5%" stopColor="#2ecc71" stopOpacity={0.1}/>
//                     <stop offset="95%" stopColor="#2ecc71" stopOpacity={0}/>
//                   </linearGradient>
//                   <linearGradient id="colorExpense" x1="0" y1="0" x2="0" y2="1">
//                     <stop offset="5%" stopColor="#e74c3c" stopOpacity={0.1}/>
//                     <stop offset="95%" stopColor="#e74c3c" stopOpacity={0}/>
//                   </linearGradient>
//                 </defs>
//                 <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#70707015" />
//                 <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: '#888', fontSize: 12}} />
//                 <YAxis axisLine={false} tickLine={false} tick={{fill: '#888', fontSize: 11}} tickFormatter={(v) => `Rs.${v/1000}k`} />
//                 <Tooltip contentStyle={{ backgroundColor: '#fff', border: '1px solid #eee', borderRadius: '12px', boxShadow: '0 4px 12px rgba(0,0,0,0.1)' }} />
//                 <Area type="monotone" dataKey="income" stroke="#2ecc71" strokeWidth={3} fillOpacity={1} fill="url(#colorIncome)" />
//                 <Area type="monotone" dataKey="expenses" stroke="#e74c3c" strokeWidth={3} fillOpacity={1} fill="url(#colorExpense)" />
//               </AreaChart>
//             </ResponsiveContainer>
//           </div>

//           {/* ── Main Content Grid ── */}
//           <div className="db-main-grid">

           
//             {/* Low Stock Alerts */}
//             <div className="db-widget db-stock-widget">
//               <div className="db-widget-header">
//                 <div>
//                   <h3>Low Stock Alerts</h3>
//                   <span className="db-widget-sub">{stats.low_stock_count} items need restocking</span>
//                 </div>
//                 {stats.low_stock_count > 0 && <span className="db-alert-chip">⚠ {stats.low_stock_count}</span>}
//               </div>
//               {lowStock.length === 0 ? (
//                 <div className="db-empty db-stock-ok">✓ All items well stocked</div>
//               ) : (
//                 <div className="db-stock-list">
//                   {lowStock.map((item, i) => {
//                     const pct = Math.min((item.quantity / item.threshold) * 100, 100);
//                     return (
//                       <div className="db-stock-row" key={i}>
//                         <div className="db-stock-info">
//                           <span className="db-stock-name">{item.name}</span>
//                           <span className="db-stock-cat">{item.category}</span>
//                         </div>
//                         <div className="db-stock-right">
//                           <span className={`db-stock-qty ${item.quantity <= 0 ? "out" : "low"}`}>{item.quantity} {item.unit}</span>
//                           <div className="db-stock-bar">
//                             <div className={`db-stock-fill ${item.quantity <= 0 ? "out" : "low"}`} style={{ width: `${pct}%` }} />
//                           </div>
//                         </div>
//                       </div>
//                     );
//                   })}
//                 </div>
//               )}
//             </div>

//             {/* Recent Reviews */}
//             <div className="db-widget db-reviews-widget">
//               <div className="db-widget-header">
//                 <div>
//                   <h3>Recent Reviews</h3>
//                   <span className="db-widget-sub">Latest patient feedback</span>
//                 </div>
//                 <span className="db-rating-chip">★ {stats.avg_rating ?? "—"}</span>
//               </div>
//               <div className="db-review-list">
//                 {recentReviews.length === 0 ? (
//                   <div className="db-empty">No reviews yet.</div>
//                 ) : recentReviews.map((r, i) => (
//                   <div className="db-review-row" key={i}>
//                     <div className="db-review-avatar">{r.customer_name.charAt(0).toUpperCase()}</div>
//                     <div className="db-review-body">
//                       <div className="db-review-top">
//                         <span className="db-review-name">{r.customer_name}</span>
//                         <StarRating rating={r.rating} />
//                       </div>
//                       <p className="db-review-comment">"{r.comment}"</p>
//                       <span className="db-review-date">{r.created_at}</span>
//                     </div>
//                   </div>
//                 ))}
//               </div>
//             </div>

//              {/* Revenue Chart */}
//             <div className="db-widget db-chart-widget">
//               <div className="db-widget-header">
//                 <div>
//                   <h3>Revenue — Last 7 Days</h3>
//                   <span className="db-widget-sub">Daily income from paid appointments</span>
//                 </div>
//                 <span className="db-total-chip">{fmt(chartData.reduce((s,d)=>s+d.revenue,0))}</span>
//               </div>
//               <ResponsiveContainer width="100%" height={200}>
//                 <BarChart data={chartData} margin={{ top: 8, right: 8, left: 0, bottom: 0 }}>
//                   <CartesianGrid strokeDasharray="3 3" stroke="#aaa7a708" vertical={false} />
//                   <XAxis dataKey="label" tick={{ fill: "#888", fontSize: 12 }} axisLine={false} tickLine={false} />
//                   <YAxis tickFormatter={v => `${(v/1000).toFixed(0)}k`} tick={{ fill: "#888", fontSize: 11 }} axisLine={false} tickLine={false} />
//                   <Tooltip content={<CustomBarTooltip />} cursor={{ fill: "#00000008" }} />
//                   <Bar dataKey="revenue" radius={[6,6,0,0]} maxBarSize={40}>
//                     {chartData.map((entry, i) => (
//                       <Cell key={i} fill={entry.revenue === maxRevenue ? "#3498db" : "#3498db55"} />
//                     ))}
//                   </Bar>
//                 </BarChart>
//               </ResponsiveContainer>
//             </div>

//             {/* Recent Appointments */}
//             <div className="db-widget db-appts-widget">
//               <div className="db-widget-header">
//                 <div>
//                   <h3>Recent Appointments</h3>
//                   <span className="db-widget-sub">Latest 8 appointments</span>
//                 </div>
//               </div>
//               <div className="db-appt-list">
//                 {recentAppts.length === 0 ? (
//                   <div className="db-empty">No appointments yet.</div>
//                 ) : recentAppts.map((a, i) => {
//                   const sc = STATUS_COLOR[a.status] || STATUS_COLOR.Pending;
//                   return (
//                     <div className="db-appt-row" key={i}>
//                       <div className="db-appt-avatar">{a.patient_name.charAt(0).toUpperCase()}</div>
//                       <div className="db-appt-info">
//                         <span className="db-appt-name">{a.patient_name}</span>
//                         <span className="db-appt-service">{a.service} · {a.date}</span>
//                       </div>
//                       <span className="db-appt-status" style={{ background: sc.bg, color: sc.text }}>
//                         <span className="db-status-dot" style={{ background: sc.dot }} />
//                         {a.status}
//                       </span>
//                     </div>
//                   );
//                 })}
//               </div>
//             </div>

            

//           </div>
          
//         </>
//       )}
//     </div>
//   );
// }

// export default Dashboard;

import React, { useEffect, useState } from "react";
import {
  XAxis, YAxis, CartesianGrid, Tooltip, 
  ResponsiveContainer, AreaChart, Area 
} from "recharts";
import "./Dashboard.css";

const fmt = (n) => `Rs. ${Number(n || 0).toLocaleString()}`;

const STATUS_COLOR = {
  Pending:   { bg: "#f39c1220", text: "#f39c12", dot: "#f39c12" },
  Approved:  { bg: "#2ecc7120", text: "#2ecc71", dot: "#2ecc71" },
  Completed: { bg: "#3498db20", text: "#3498db", dot: "#3498db" },
  Cancelled: { bg: "#e74c3c20", text: "#e74c3c", dot: "#e74c3c" },
};

const STAT_CARDS = [
  { key: "total_patients",    label: "Total Patients",        icon: "👥", accent: "#3498db" },
  { key: "today_appointments",    label: "Today's Appointments",  icon: "📅", accent: "#2ecc71" },
  { key: "total_employees",       label: "Active Employees",      icon: "👤", accent: "#3498db" },
];

function StarRating({ rating }) {
  return (
    <span className="db-stars">
      {[1, 2, 3, 4, 5].map(i => (
        <span key={i} className={i <= rating ? "db-star on" : "db-star off"}>★</span>
      ))}
    </span>
  );
}

function Dashboard() {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [time, setTime] = useState(new Date());

  useEffect(() => {
    refresh();
    const tick = setInterval(() => setTime(new Date()), 1000);
    return () => clearInterval(tick);
  }, []);

  const refresh = () => {
    setLoading(true);
    fetch("http://127.0.0.1:8000/dashboard/")
      .then(r => r.json())
      .then(d => { setData(d); setLoading(false); })
      .catch(() => setLoading(false));
  };

  const stats = data?.stats || {};
  const recentAppts = data?.recent_appointments || [];
  const recentReviews = data?.recent_reviews || [];
  const lowStock = data?.low_stock_items || [];

  return (
    <div className="db-container">
      {/* ── Top Bar ── */}
      <div className="db-topbar">
        <div className="db-topbar-left">
          <h1 className="db-title">Dashboard Overview</h1>
        </div>
        <div className="db-topbar-right">
          <div className="db-clock">
            <span className="db-clock-time">
              {time.toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit", second: "2-digit" })}
            </span>
            <span className="db-clock-date">
              {time.toLocaleDateString("en-US", { weekday: "long", month: "long", day: "numeric", year: "numeric" })}
            </span>
          </div>
          <button className="db-refresh-btn" onClick={refresh}>↻ Refresh</button>
        </div>
      </div>

      {loading ? (
        <div className="db-loading">
          <div className="db-spinner" />
          <span>Loading dashboard...</span>
        </div>
      ) : (
        <>
          {/* ── Stat Cards ── */}
          <div className="db-stats-grid">
            {STAT_CARDS.map((card) => (
              <div className="db-stat-card" key={card.key} style={{ "--accent": card.accent }}>
                <div className="db-stat-icon">{card.icon}</div>
                <div className="db-stat-body">
                  <span className="db-stat-value">{stats[card.key] ?? 0}</span>
                  <span className="db-stat-label">{card.label}</span>
                </div>
                <div className="db-stat-glow" />
              </div>
            ))}
            <div className="db-stat-card" style={{ "--accent": "#f1c40f" }}>
              <div className="db-stat-icon">⭐</div>
              <div className="db-stat-body">
                <span className="db-stat-value">{stats.avg_rating ?? "—"}<span className="db-stat-unit">/5</span></span>
                <span className="db-stat-label">Average Rating</span>
              </div>
              <div className="db-stat-glow" />
            </div>
          </div>

          {/* ── Main Content Grid ── */}
          <div className="db-main-grid">
            
            {/* Row 1: Financial Overview (Half Width) */}
            <div className="db-widget db-finance-overview">
              <div className="db-widget-header">
                <div>
                  <h3>Financial Overview</h3>
                  <span className="db-widget-sub">Monthly Income vs Expenses</span>
                </div>
              </div>
              <ResponsiveContainer width="100%" height={250}>
                <AreaChart data={data?.financial_comparison || []} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                  <defs>
                    <linearGradient id="colorIncome" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#2ecc71" stopOpacity={0.1}/>
                      <stop offset="95%" stopColor="#2ecc71" stopOpacity={0}/>
                    </linearGradient>
                    <linearGradient id="colorExpense" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#e74c3c" stopOpacity={0.1}/>
                      <stop offset="95%" stopColor="#e74c3c" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#70707015" />
                  <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: '#888', fontSize: 11}} />
                  <YAxis axisLine={false} tickLine={false} tick={{fill: '#888', fontSize: 10}} tickFormatter={(v) => `${v/1000}k`} />
                  <Tooltip contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 4px 12px rgba(0,0,0,0.1)' }} />
                  <Area type="monotone" dataKey="income" stroke="#2ecc71" strokeWidth={3} fillOpacity={1} fill="url(#colorIncome)" />
                  <Area type="monotone" dataKey="expenses" stroke="#e74c3c" strokeWidth={3} fillOpacity={1} fill="url(#colorExpense)" />
                </AreaChart>
              </ResponsiveContainer>
            </div>

            {/* Row 1: Recent Appointments (Half Width) */}
            <div className="db-widget db-appts-widget">
              <div className="db-widget-header">
                <div>
                  <h3>Recent Appointments</h3>
                  <span className="db-widget-sub">Latest updates</span>
                </div>
              </div>
              <div className="db-appt-list">
                {recentAppts.length === 0 ? (
                  <div className="db-empty">No appointments yet.</div>
                ) : recentAppts.slice(0, 5).map((a, i) => {
                  const sc = STATUS_COLOR[a.status] || STATUS_COLOR.Pending;
                  return (
                    <div className="db-appt-row" key={i}>
                      <div className="db-appt-avatar">{a.patient_name.charAt(0).toUpperCase()}</div>
                      <div className="db-appt-info">
                        <span className="db-appt-name">{a.patient_name}</span>
                        <span className="db-appt-service">{a.date}</span>
                      </div>
                      <span className="db-appt-status" style={{ background: sc.bg, color: sc.text }}>
                        {a.status}
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Row 2: Low Stock Alerts */}
            <div className="db-widget db-stock-widget">
              <div className="db-widget-header">
                <div>
                  <h3>Low Stock Alerts</h3>
                  <span className="db-widget-sub">{stats.low_stock_count} items need care</span>
                </div>
                {stats.low_stock_count > 0 && <span className="db-alert-chip">⚠</span>}
              </div>
              <div className="db-stock-list">
                {lowStock.length === 0 ? (
                  <div className="db-empty db-stock-ok">✓ All stocked up</div>
                ) : lowStock.slice(0, 4).map((item, i) => (
                  <div className="db-stock-row" key={i}>
                    <div className="db-stock-info">
                      <span className="db-stock-name">{item.name}</span>
                      <div className="db-stock-bar">
                        <div className={`db-stock-fill ${item.quantity <= 0 ? "out" : "low"}`} style={{ width: `${Math.min((item.quantity / item.threshold) * 100, 100)}%` }} />
                      </div>
                    </div>
                    <span className={`db-stock-qty ${item.quantity <= 0 ? "out" : "low"}`}>{item.quantity}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Row 2: Recent Reviews */}
            <div className="db-widget db-reviews-widget">
              <div className="db-widget-header">
                <div>
                  <h3>Recent Reviews</h3>
                  <span className="db-widget-sub">Patient feedback</span>
                </div>
                <span className="db-rating-chip">★ {stats.avg_rating ?? "—"}</span>
              </div>
              <div className="db-review-list">
                {recentReviews.length === 0 ? (
                  <div className="db-empty">No reviews.</div>
                ) : recentReviews.slice(0, 3).map((r, i) => (
                  <div className="db-review-row" key={i}>
                    <div className="db-review-body">
                      <div className="db-review-top">
                        <span className="db-review-name">{r.customer_name}</span>
                        <StarRating rating={r.rating} />
                      </div>
                      <p className="db-review-comment">"{r.comment}"</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

          </div>
        </>
      )}
    </div>
  );
}

export default Dashboard;