// import React, { useEffect, useState, useRef } from "react";
// import "./Expenses.css";

// const CATEGORIES = ["Rent", "Utilities", "Maintenance", "Other"];
// const ALL_CATS = ["All", "Salary", "Inventory", "Rent", "Utilities", "Maintenance", "Other"];

// const EMPTY_FORM = {
//   title: "", category: "Rent", amount: "", month: "", note: "",
// };

// function Expenses() {
//   const today = new Date();
//   const currentMonth = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, "0")}`;

//   const [selectedMonth, setSelectedMonth] = useState(currentMonth);
//   const [summary, setSummary] = useState(null);
//   const [loading, setLoading] = useState(true);
//   const [activeTab, setActiveTab] = useState("overview");   // overview | expenses | salary | inventory
//   const [catFilter, setCatFilter] = useState("All");
//   const [showModal, setShowModal] = useState(false);
//   const [editItem, setEditItem] = useState(null);
//   const [form, setForm] = useState(EMPTY_FORM);
//   const [saving, setSaving] = useState(false);
//   const [deleteConfirm, setDeleteConfirm] = useState(null);
//   const printRef = useRef();

//   // ─── Fetch summary ───────────────────────────────────────────────────
//   const fetchSummary = async () => {
//     setLoading(true);
//     try {
//       const res = await fetch(`http://127.0.0.1:8000/expenses/summary/?month=${selectedMonth}`);
//       const data = await res.json();
//       setSummary(data);
//     } catch (err) {
//       console.error("Error fetching summary:", err);
//     } finally {
//       setLoading(false);
//     }
//   };

//   useEffect(() => { fetchSummary(); }, [selectedMonth]);

//   // ─── Format currency ─────────────────────────────────────────────────
//   const fmt = (n) => `Rs. ${Number(n || 0).toLocaleString()}`;

//   // ─── Filtered manual expenses ────────────────────────────────────────
//   const manualExpenses = summary?.manual_expenses || [];
//   const filteredExpenses = catFilter === "All"
//     ? manualExpenses
//     : manualExpenses.filter((e) => e.category === catFilter);

//   // ─── Open modals ─────────────────────────────────────────────────────
//   const openAdd = () => {
//     setEditItem(null);
//     setForm({ ...EMPTY_FORM, month: selectedMonth });
//     setShowModal(true);
//   };

//   const openEdit = (item) => {
//     setEditItem(item);
//     setForm({
//       title: item.title || "",
//       category: item.category || "Rent",
//       amount: item.amount || "",
//       month: item.month || selectedMonth,
//       note: item.note || "",
//     });
//     setShowModal(true);
//   };

//   const closeModal = () => { setShowModal(false); setEditItem(null); };
//   const handleChange = (e) => setForm((p) => ({ ...p, [e.target.name]: e.target.value }));

//   // ─── Save ────────────────────────────────────────────────────────────
//   const handleSave = async () => {
//     if (!form.title.trim()) return alert("Title is required.");
//     if (!form.amount || parseFloat(form.amount) <= 0) return alert("Enter a valid amount.");
//     setSaving(true);
//     try {
//       const url = editItem
//         ? `http://127.0.0.1:8000/expenses/update/${editItem.id}/`
//         : "http://127.0.0.1:8000/expenses/create/";
//       const res = await fetch(url, {
//         method: "POST",
//         headers: { "Content-Type": "application/json" },
//         body: JSON.stringify(form),
//       });
//       if (res.ok) { await fetchSummary(); closeModal(); }
//       else { const e = await res.json(); alert("Error: " + (e.error || "Unknown")); }
//     } catch { alert("Network error."); }
//     finally { setSaving(false); }
//   };

//   // ─── Delete ──────────────────────────────────────────────────────────
//   const handleDelete = async (id) => {
//     try {
//       const res = await fetch(`http://127.0.0.1:8000/expenses/delete/${id}/`, { method: "POST" });
//       if (res.ok) { await fetchSummary(); setDeleteConfirm(null); }
//       else alert("Failed to delete.");
//     } catch { alert("Network error."); }
//   };

//   // ─── Print ───────────────────────────────────────────────────────────
//   const handlePrint = () => window.print();

//   // ─── Month nav ───────────────────────────────────────────────────────
//   const changeMonth = (dir) => {
//     const [y, m] = selectedMonth.split("-").map(Number);
//     const d = new Date(y, m - 1 + dir, 1);
//     setSelectedMonth(`${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`);
//   };

//   const monthLabel = new Date(selectedMonth + "-01").toLocaleDateString("en-US", { month: "long", year: "numeric" });

//   if (loading) return <div className="exp-loading">Loading financial summary...</div>;

//   const breakdown = summary?.breakdown?.by_category || {};
//   const totalExpenses = summary?.total_expenses || 0;

//   return (
//     <div className="exp-container" ref={printRef}>

//       {/* ── Header ── */}
//       <div className="exp-header no-print-hide">
//         <h2>Expenses &amp; Financial Report</h2>
//         <div className="exp-header-actions">
//           <button className="exp-print-btn" onClick={handlePrint}>Print / Export</button>
//           <button className="exp-add-btn" onClick={openAdd}>+ Add Expense</button>
//         </div>
//       </div>

//       {/* ── Month Selector ── */}
//       <div className="exp-month-bar">
//         <button className="exp-month-nav" onClick={() => changeMonth(-1)}>‹</button>
//         <span className="exp-month-label">{monthLabel}</span>
//         <button className="exp-month-nav" onClick={() => changeMonth(1)}>›</button>
//         <input
//           type="month"
//           value={selectedMonth}
//           onChange={(e) => setSelectedMonth(e.target.value)}
//           className="exp-month-input"
//         />
//       </div>

//       {/* ── Summary Cards ── */}
//       <div className="exp-summary-cards">
//         <div className="exp-card income">
//           <span className="exp-card-label">Total Income</span>
//           <span className="exp-card-value">{fmt(summary?.total_income)}</span>
//           <span className="exp-card-sub">Paid payments this month</span>
//         </div>
//         <div className="exp-card expenses">
//           <span className="exp-card-label">Total Expenses</span>
//           <span className="exp-card-value">{fmt(summary?.total_expenses)}</span>
//           <span className="exp-card-sub">All categories combined</span>
//         </div>
//         <div className={`exp-card profit ${(summary?.net_profit || 0) >= 0 ? "positive" : "negative"}`}>
//           <span className="exp-card-label">Net Profit</span>
//           <span className="exp-card-value">{fmt(summary?.net_profit)}</span>
//           <span className="exp-card-sub">{(summary?.net_profit || 0) >= 0 ? "Profitable month" : "Loss this month"}</span>
//         </div>
//       </div>

//       {/* ── Category Breakdown ── */}
//       <div className="exp-breakdown-section">
//         <h3 className="exp-section-title">Category Breakdown</h3>
//         <div className="exp-breakdown-list">
//           {Object.entries(breakdown).map(([cat, amount]) => {
//             const pct = totalExpenses > 0 ? ((amount / totalExpenses) * 100).toFixed(1) : 0;
//             return (
//               <div className="exp-breakdown-row" key={cat}>
//                 <span className={`exp-cat-dot cat-${cat.toLowerCase()}`} />
//                 <span className="exp-breakdown-cat">{cat}</span>
//                 <div className="exp-breakdown-bar-track">
//                   <div className="exp-breakdown-bar-fill" style={{ width: `${pct}%` }} />
//                 </div>
//                 <span className="exp-breakdown-pct">{pct}%</span>
//                 <span className="exp-breakdown-amt">{fmt(amount)}</span>
//               </div>
//             );
//           })}
//           {Object.keys(breakdown).length === 0 && (
//             <p className="exp-no-data">No expenses recorded for this month.</p>
//           )}
//         </div>
//       </div>

//       {/* ── Tabs ── */}
//       <div className="exp-tabs no-print-hide">
//         {[["overview", "Overview"], ["expenses", "Manual Expenses"], ["salary", "Salary Detail"], ["inventory", "Inventory Detail"]].map(([key, label]) => (
//           <button key={key} className={`exp-tab ${activeTab === key ? "active" : ""}`} onClick={() => setActiveTab(key)}>
//             {label}
//           </button>
//         ))}
//       </div>

//       {/* ── Overview Tab ── */}
//       {activeTab === "overview" && (
//         <div className="exp-overview-grid">
//           <div className="exp-overview-card">
//             <div className="exp-overview-title">Staff Salaries</div>
//             <div className="exp-overview-amount">{fmt(summary?.breakdown?.salary)}</div>
//             <div className="exp-overview-sub">{summary?.salary_detail?.length || 0} active employees</div>
//           </div>
//           <div className="exp-overview-card">
//             <div className="exp-overview-title">Inventory Cost</div>
//             <div className="exp-overview-amount">{fmt(summary?.breakdown?.inventory)}</div>
//             <div className="exp-overview-sub">{summary?.inventory_detail?.length || 0} items in stock</div>
//           </div>
//           <div className="exp-overview-card">
//             <div className="exp-overview-title">Other Expenses</div>
//             <div className="exp-overview-amount">{fmt(summary?.breakdown?.manual)}</div>
//             <div className="exp-overview-sub">{manualExpenses.length} manual entries</div>
//           </div>
//         </div>
//       )}

//       {/* ── Manual Expenses Tab ── */}
//       {activeTab === "expenses" && (
//         <div>
//           <div className="exp-filter-row no-print-hide">
//             {ALL_CATS.filter(c => !["Salary","Inventory"].includes(c)).map((c) => (
//               <button key={c} className={`exp-filter-btn ${catFilter === c ? "active" : ""}`} onClick={() => setCatFilter(c)}>{c}</button>
//             ))}
//           </div>
//           {filteredExpenses.length === 0 ? (
//             <div className="exp-empty">No manual expenses for this month. Click "+ Add Expense" to add one.</div>
//           ) : (
//             <div className="exp-table-wrap">
//               <table className="exp-table">
//                 <thead>
//                   <tr>
//                     <th>Title</th>
//                     <th>Category</th>
//                     <th>Amount</th>
//                     <th>Month</th>
//                     <th>Note</th>
//                     <th>Date Added</th>
//                     <th className="no-print-hide">Actions</th>
//                   </tr>
//                 </thead>
//                 <tbody>
//                   {filteredExpenses.map((e) => (
//                     <tr key={e.id}>
//                       <td className="exp-title-cell">{e.title}</td>
//                       <td><span className={`exp-cat-badge cat-${e.category.toLowerCase()}`}>{e.category}</span></td>
//                       <td className="exp-amount-cell">{fmt(e.amount)}</td>
//                       <td>{e.month}</td>
//                       <td className="exp-note">{e.note || "—"}</td>
//                       <td>{e.created_at}</td>
//                       <td className="no-print-hide">
//                         <div className="exp-actions">
//                           <button className="exp-edit-btn" onClick={() => openEdit(e)}>Edit</button>
//                           <button className="exp-delete-btn" onClick={() => setDeleteConfirm(e.id)}>Delete</button>
//                         </div>
//                       </td>
//                     </tr>
//                   ))}
//                 </tbody>
//                 <tfoot>
//                   <tr>
//                     <td colSpan="2"><strong>Total</strong></td>
//                     <td className="exp-amount-cell"><strong>{fmt(filteredExpenses.reduce((s, e) => s + e.amount, 0))}</strong></td>
//                     <td colSpan="4" />
//                   </tr>
//                 </tfoot>
//               </table>
//             </div>
//           )}
//         </div>
//       )}

//       {/* ── Salary Detail Tab ── */}
//       {activeTab === "salary" && (
//         <div className="exp-table-wrap">
//           <table className="exp-table">
//             <thead>
//               <tr><th>Employee Name</th><th>Designation</th><th>Monthly Salary</th></tr>
//             </thead>
//             <tbody>
//               {(summary?.salary_detail || []).map((s, i) => (
//                 <tr key={i}>
//                   <td>{s.name}</td>
//                   <td>{s.designation || "—"}</td>
//                   <td className="exp-amount-cell">{fmt(s.salary)}</td>
//                 </tr>
//               ))}
//               {(summary?.salary_detail || []).length === 0 && (
//                 <tr><td colSpan="3" className="exp-empty">No active employees found.</td></tr>
//               )}
//             </tbody>
//             <tfoot>
//               <tr>
//                 <td colSpan="2"><strong>Total Salaries</strong></td>
//                 <td className="exp-amount-cell"><strong>{fmt(summary?.breakdown?.salary)}</strong></td>
//               </tr>
//             </tfoot>
//           </table>
//         </div>
//       )}

//       {/* ── Inventory Detail Tab ── */}
//       {activeTab === "inventory" && (
//         <div className="exp-table-wrap">
//           <table className="exp-table">
//             <thead>
//               <tr><th>Item Name</th><th>Quantity</th><th>Unit</th><th>Cost Price</th><th>Total Cost</th></tr>
//             </thead>
//             <tbody>
//               {(summary?.inventory_detail || []).map((item, i) => (
//                 <tr key={i}>
//                   <td>{item.name}</td>
//                   <td>{item.quantity}</td>
//                   <td>{item.unit}</td>
//                   <td>{fmt(item.cost_price)}</td>
//                   <td className="exp-amount-cell">{fmt(item.total)}</td>
//                 </tr>
//               ))}
//               {(summary?.inventory_detail || []).length === 0 && (
//                 <tr><td colSpan="5" className="exp-empty">No inventory cost data found.</td></tr>
//               )}
//             </tbody>
//             <tfoot>
//               <tr>
//                 <td colSpan="4"><strong>Total Inventory Cost</strong></td>
//                 <td className="exp-amount-cell"><strong>{fmt(summary?.breakdown?.inventory)}</strong></td>
//               </tr>
//             </tfoot>
//           </table>
//         </div>
//       )}

//       {/* ── Add/Edit Modal ── */}
//       {showModal && (
//         <>
//           <div className="exp-overlay" onClick={closeModal} />
//           <div className="exp-modal">
//             <h3>{editItem ? "Edit Expense" : "Add New Expense"}</h3>
//             <div className="exp-form-grid">
//               <div className="exp-field exp-field-full">
//                 <label>Title *</label>
//                 <input name="title" value={form.title} onChange={handleChange} placeholder="e.g. March Rent, Electricity Bill" />
//               </div>
//               <div className="exp-field">
//                 <label>Category *</label>
//                 <select name="category" value={form.category} onChange={handleChange}>
//                   {CATEGORIES.map(c => <option key={c}>{c}</option>)}
//                 </select>
//               </div>
//               <div className="exp-field">
//                 <label>Amount (Rs.) *</label>
//                 <input name="amount" type="number" value={form.amount} onChange={handleChange} placeholder="e.g. 25000" />
//               </div>
//               <div className="exp-field">
//                 <label>Month</label>
//                 <input name="month" type="month" value={form.month} onChange={handleChange} />
//               </div>
//               <div className="exp-field exp-field-full">
//                 <label>Note (optional)</label>
//                 <input name="note" value={form.note} onChange={handleChange} placeholder="Any extra detail..." />
//               </div>
//             </div>
//             <div className="exp-modal-actions">
//               <button className="exp-save-btn" onClick={handleSave} disabled={saving}>
//                 {saving ? "Saving..." : editItem ? "Update" : "Add Expense"}
//               </button>
//               <button className="exp-cancel-btn" onClick={closeModal}>Cancel</button>
//             </div>
//           </div>
//         </>
//       )}

//       {/* ── Delete Confirm ── */}
//       {deleteConfirm && (
//         <>
//           <div className="exp-overlay" onClick={() => setDeleteConfirm(null)} />
//           <div className="exp-confirm-modal">
//             <h3>Delete this expense?</h3>
//             <p>This cannot be undone.</p>
//             <div className="exp-confirm-actions">
//               <button className="exp-delete-btn" onClick={() => handleDelete(deleteConfirm)}>Yes, Delete</button>
//               <button className="exp-cancel-btn" onClick={() => setDeleteConfirm(null)}>Cancel</button>
//             </div>
//           </div>
//         </>
//       )}
//     </div>
//   );
// }

// export default Expenses;


import React, { useEffect, useState, useRef } from "react";
import "./Expenses.css";

const CATEGORIES = ["Rent", "Utilities", "Maintenance", "Other"];
const ALL_CATS = ["All", "Salary", "Inventory", "Rent", "Utilities", "Maintenance", "Other"];

const EMPTY_FORM = {
  title: "", category: "Rent", amount: "", month: "", note: "",
};

function Expenses() {
  const today = new Date();
  const currentMonth = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, "0")}`;

  const [selectedMonth, setSelectedMonth] = useState(currentMonth);
  const [summary, setSummary] = useState(null);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState("overview");   // overview | expenses | salary | inventory
  const [catFilter, setCatFilter] = useState("All");
  const [showModal, setShowModal] = useState(false);
  const [editItem, setEditItem] = useState(null);
  const [form, setForm] = useState(EMPTY_FORM);
  const [saving, setSaving] = useState(false);
  const [deleteConfirm, setDeleteConfirm] = useState(null);
  const printRef = useRef();

  // ─── Fetch summary ───────────────────────────────────────────────────
  const fetchSummary = async () => {
    setLoading(true);
    try {
      const res = await fetch(`http://127.0.0.1:8000/expenses/summary/?month=${selectedMonth}`);
      const data = await res.json();
      setSummary(data);
    } catch (err) {
      console.error("Error fetching summary:", err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchSummary(); }, [selectedMonth]);

  // ─── Format currency ─────────────────────────────────────────────────
  const fmt = (n) => `Rs. ${Number(n || 0).toLocaleString()}`;

  // ─── Filtered manual expenses ────────────────────────────────────────
  const manualExpenses = summary?.manual_expenses || [];
  const filteredExpenses = catFilter === "All"
    ? manualExpenses
    : manualExpenses.filter((e) => e.category === catFilter);

  // ─── Open modals ─────────────────────────────────────────────────────
  const openAdd = () => {
    setEditItem(null);
    setForm({ ...EMPTY_FORM, month: selectedMonth });
    setShowModal(true);
  };

  const openEdit = (item) => {
    setEditItem(item);
    setForm({
      title: item.title || "",
      category: item.category || "Rent",
      amount: item.amount || "",
      month: item.month || selectedMonth,
      note: item.note || "",
    });
    setShowModal(true);
  };

  const closeModal = () => { setShowModal(false); setEditItem(null); };
  const handleChange = (e) => setForm((p) => ({ ...p, [e.target.name]: e.target.value }));

  // ─── Save ────────────────────────────────────────────────────────────
  const handleSave = async () => {
    if (!form.title.trim()) return alert("Title is required.");
    if (!form.amount || parseFloat(form.amount) <= 0) return alert("Enter a valid amount.");
    setSaving(true);
    try {
      const url = editItem
        ? `http://127.0.0.1:8000/expenses/update/${editItem.id}/`
        : "http://127.0.0.1:8000/expenses/create/";
      const res = await fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      if (res.ok) { await fetchSummary(); closeModal(); }
      else { const e = await res.json(); alert("Error: " + (e.error || "Unknown")); }
    } catch { alert("Network error."); }
    finally { setSaving(false); }
  };

  // ─── Delete ──────────────────────────────────────────────────────────
  const handleDelete = async (id) => {
    try {
      const res = await fetch(`http://127.0.0.1:8000/expenses/delete/${id}/`, { method: "POST" });
      if (res.ok) { await fetchSummary(); setDeleteConfirm(null); }
      else alert("Failed to delete.");
    } catch { alert("Network error."); }
  };

  // ─── Print ───────────────────────────────────────────────────────────
  const handlePrint = () => window.print();

  // ─── Month nav ───────────────────────────────────────────────────────
  const changeMonth = (dir) => {
    const [y, m] = selectedMonth.split("-").map(Number);
    const d = new Date(y, m - 1 + dir, 1);
    setSelectedMonth(`${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`);
  };

  const monthLabel = new Date(selectedMonth + "-01").toLocaleDateString("en-US", { month: "long", year: "numeric" });

  if (loading) return <div className="exp-loading">Loading financial summary...</div>;

  const breakdown = summary?.breakdown?.by_category || {};
  const totalExpenses = summary?.total_expenses || 0;

  return (
    <div className="exp-container" ref={printRef}>

      {/* ── Header ── */}
      <div className="exp-header no-print-hide">
        <h2>Expenses &amp; Financial Report</h2>
        <div className="exp-header-actions">
          <button className="exp-print-btn" onClick={handlePrint}>Print / Export</button>
          <button className="exp-add-btn" onClick={openAdd}>+ Add Expense</button>
        </div>
      </div>

      {/* ── Month Selector ── */}
      <div className="exp-month-bar">
        <button className="exp-month-nav" onClick={() => changeMonth(-1)}>‹</button>
        <span className="exp-month-label">{monthLabel}</span>
        <button className="exp-month-nav" onClick={() => changeMonth(1)}>›</button>
        <input
          type="month"
          value={selectedMonth}
          onChange={(e) => setSelectedMonth(e.target.value)}
          className="exp-month-input"
        />
      </div>

      {/* ── Summary Cards ── */}
      <div className="exp-summary-cards">
        <div className="exp-card income">
          <span className="exp-card-label">Total Income</span>
          <span className="exp-card-value">{fmt(summary?.total_income)}</span>
          <span className="exp-card-sub">Paid payments this month</span>
        </div>
        <div className="exp-card expenses">
          <span className="exp-card-label">Total Expenses</span>
          <span className="exp-card-value">{fmt(summary?.total_expenses)}</span>
          <span className="exp-card-sub">All categories combined</span>
        </div>
        <div className={`exp-card profit ${(summary?.net_profit || 0) >= 0 ? "positive" : "negative"}`}>
          <span className="exp-card-label">Net Profit</span>
          <span className="exp-card-value">{fmt(summary?.net_profit)}</span>
          <span className="exp-card-sub">{(summary?.net_profit || 0) >= 0 ? "Profitable month" : "Loss this month"}</span>
        </div>
      </div>

      {/* ── Category Breakdown ── */}
      <div className="exp-breakdown-section">
        <h3 className="exp-section-title">Category Breakdown</h3>
        <div className="exp-breakdown-list">
          {Object.entries(breakdown).map(([cat, amount]) => {
            const pct = totalExpenses > 0 ? ((amount / totalExpenses) * 100).toFixed(1) : 0;
            return (
              <div className="exp-breakdown-row" key={cat}>
                <span className={`exp-cat-dot cat-${cat.toLowerCase()}`} />
                <span className="exp-breakdown-cat">{cat}</span>
                <div className="exp-breakdown-bar-track">
                  <div className="exp-breakdown-bar-fill" style={{ width: `${pct}%` }} />
                </div>
                <span className="exp-breakdown-pct">{pct}%</span>
                <span className="exp-breakdown-amt">{fmt(amount)}</span>
              </div>
            );
          })}
          {Object.keys(breakdown).length === 0 && (
            <p className="exp-no-data">No expenses recorded for this month.</p>
          )}
        </div>
      </div>

      {/* ── Tabs ── */}
      <div className="exp-tabs no-print-hide">
        {[["overview", "Overview"], ["expenses", "Manual Expenses"], ["salary", "Salary Detail"], ["inventory", "Inventory Detail"]].map(([key, label]) => (
          <button key={key} className={`exp-tab ${activeTab === key ? "active" : ""}`} onClick={() => setActiveTab(key)}>
            {label}
          </button>
        ))}
      </div>

      {/* ── Overview Tab ── */}
      {activeTab === "overview" && (
        <div className="exp-overview-grid">
          <div className="exp-overview-card">
            <div className="exp-overview-title">Staff Salaries</div>
            <div className="exp-overview-amount">{fmt(summary?.breakdown?.salary)}</div>
            <div className="exp-overview-sub">{summary?.salary_detail?.length || 0} active employees</div>
          </div>
          <div className="exp-overview-card">
            <div className="exp-overview-title">Inventory Cost</div>
            <div className="exp-overview-amount">{fmt(summary?.breakdown?.inventory)}</div>
            <div className="exp-overview-sub">{summary?.inventory_detail?.length || 0} items in stock</div>
          </div>
          <div className="exp-overview-card">
            <div className="exp-overview-title">Other Expenses</div>
            <div className="exp-overview-amount">{fmt(summary?.breakdown?.manual)}</div>
            <div className="exp-overview-sub">{manualExpenses.length} manual entries</div>
          </div>
        </div>
      )}

      {/* ── Manual Expenses Tab ── */}
      {activeTab === "expenses" && (
        <div>
          <div className="exp-filter-row no-print-hide">
            {ALL_CATS.filter(c => !["Salary","Inventory"].includes(c)).map((c) => (
              <button key={c} className={`exp-filter-btn ${catFilter === c ? "active" : ""}`} onClick={() => setCatFilter(c)}>{c}</button>
            ))}
          </div>
          {filteredExpenses.length === 0 ? (
            <div className="exp-empty">No manual expenses for this month. Click "+ Add Expense" to add one.</div>
          ) : (
            <div className="exp-table-wrap">
              <table className="exp-table">
                <thead>
                  <tr>
                    <th>Title</th>
                    <th>Category</th>
                    <th>Amount</th>
                    <th>Month</th>
                    <th>Note</th>
                    <th>Date Added</th>
                    <th className="no-print-hide">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredExpenses.map((e) => (
                    <tr key={e.id}>
                      <td className="exp-title-cell">{e.title}</td>
                      <td><span className={`exp-cat-badge cat-${e.category.toLowerCase()}`}>{e.category}</span></td>
                      <td className="exp-amount-cell">{fmt(e.amount)}</td>
                      <td>{e.month}</td>
                      <td className="exp-note">{e.note || "—"}</td>
                      <td>{e.created_at}</td>
                      <td className="no-print-hide">
                        <div className="exp-actions">
                          <button className="exp-edit-btn" onClick={() => openEdit(e)}>Edit</button>
                          <button className="exp-delete-btn" onClick={() => setDeleteConfirm(e.id)}>Delete</button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
                <tfoot>
                  <tr>
                    <td colSpan="2"><strong>Total</strong></td>
                    <td className="exp-amount-cell"><strong>{fmt(filteredExpenses.reduce((s, e) => s + e.amount, 0))}</strong></td>
                    <td colSpan="4" />
                  </tr>
                </tfoot>
              </table>
            </div>
          )}
        </div>
      )}

      {/* ── Salary Detail Tab ── */}
      {activeTab === "salary" && (
        <div className="exp-table-wrap">
          <table className="exp-table">
            <thead>
              <tr>
                <th>Employee Name</th>
                <th>Designation</th>
                <th>Monthly Salary</th>
                <th>Salary Status</th>
              </tr>
            </thead>
            <tbody>
              {(summary?.salary_detail || []).map((s, i) => (
                <tr key={i}>
                  <td>{s.name}</td>
                  <td>{s.designation || "—"}</td>
                  <td className="exp-amount-cell">{fmt(s.salary)}</td>
                  <td>
                    <span className={`exp-salary-status-badge ${(s.salary_status || "Unpaid") === "Paid" ? "paid" : "unpaid"}`}>
                      {s.salary_status || "Unpaid"}
                    </span>
                  </td>
                </tr>
              ))}
              {(summary?.salary_detail || []).length === 0 && (
                <tr><td colSpan="4" className="exp-empty">No active employees found.</td></tr>
              )}
            </tbody>
            <tfoot>
              <tr>
                <td colSpan="3"><strong>Total Paid Salaries (included in expenses)</strong></td>
                <td className="exp-amount-cell"><strong>{fmt(summary?.breakdown?.salary)}</strong></td>
              </tr>
            </tfoot>
          </table>
        </div>
      )}

      {/* ── Inventory Detail Tab ── */}
      {activeTab === "inventory" && (
        <div className="exp-table-wrap">
          <table className="exp-table">
            <thead>
              <tr><th>Item Name</th><th>Quantity</th><th>Unit</th><th>Cost Price</th><th>Total Cost</th></tr>
            </thead>
            <tbody>
              {(summary?.inventory_detail || []).map((item, i) => (
                <tr key={i}>
                  <td>{item.name}</td>
                  <td>{item.quantity}</td>
                  <td>{item.unit}</td>
                  <td>{fmt(item.cost_price)}</td>
                  <td className="exp-amount-cell">{fmt(item.total)}</td>
                </tr>
              ))}
              {(summary?.inventory_detail || []).length === 0 && (
                <tr><td colSpan="5" className="exp-empty">No inventory cost data found.</td></tr>
              )}
            </tbody>
            <tfoot>
              <tr>
                <td colSpan="4"><strong>Total Inventory Cost</strong></td>
                <td className="exp-amount-cell"><strong>{fmt(summary?.breakdown?.inventory)}</strong></td>
              </tr>
            </tfoot>
          </table>
        </div>
      )}

      {/* ── Add/Edit Modal ── */}
      {showModal && (
        <>
          <div className="exp-overlay" onClick={closeModal} />
          <div className="exp-modal">
            <h3>{editItem ? "Edit Expense" : "Add New Expense"}</h3>
            <div className="exp-form-grid">
              <div className="exp-field exp-field-full">
                <label>Title *</label>
                <input name="title" value={form.title} onChange={handleChange} placeholder="e.g. March Rent, Electricity Bill" />
              </div>
              <div className="exp-field">
                <label>Category *</label>
                <select name="category" value={form.category} onChange={handleChange}>
                  {CATEGORIES.map(c => <option key={c}>{c}</option>)}
                </select>
              </div>
              <div className="exp-field">
                <label>Amount (Rs.) *</label>
                <input name="amount" type="number" value={form.amount} onChange={handleChange} placeholder="e.g. 25000" />
              </div>
              <div className="exp-field">
                <label>Month</label>
                <input name="month" type="month" value={form.month} onChange={handleChange} />
              </div>
              <div className="exp-field exp-field-full">
                <label>Note (optional)</label>
                <input name="note" value={form.note} onChange={handleChange} placeholder="Any extra detail..." />
              </div>
            </div>
            <div className="exp-modal-actions">
              <button className="exp-save-btn" onClick={handleSave} disabled={saving}>
                {saving ? "Saving..." : editItem ? "Update" : "Add Expense"}
              </button>
              <button className="exp-cancel-btn" onClick={closeModal}>Cancel</button>
            </div>
          </div>
        </>
      )}

      {/* ── Delete Confirm ── */}
      {deleteConfirm && (
        <>
          <div className="exp-overlay" onClick={() => setDeleteConfirm(null)} />
          <div className="exp-confirm-modal">
            <h3>Delete this expense?</h3>
            <p>This cannot be undone.</p>
            <div className="exp-confirm-actions">
              <button className="exp-delete-btn" onClick={() => handleDelete(deleteConfirm)}>Yes, Delete</button>
              <button className="exp-cancel-btn" onClick={() => setDeleteConfirm(null)}>Cancel</button>
            </div>
          </div>
        </>
      )}
    </div>
  );
}

export default Expenses;