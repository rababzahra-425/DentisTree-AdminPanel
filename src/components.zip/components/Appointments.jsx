import React, { useEffect, useState } from 'react';
import './Appointments.css';

function Appointments() {
  const [data, setData] = useState([]);
  const [selectedPatient, setSelectedPatient] = useState(null); // Detail Modal ke liye

  const fetchAppointments = () => {
    fetch('http://127.0.0.1:8000/appointments/')
      .then(res => res.json())
      .then(data => setData(data))
      .catch(err => console.error("Fetch error:", err));
  };

  useEffect(() => {
    fetchAppointments();
  }, []);

  const updateStatus = (id, status) => {
    fetch(`http://127.0.0.1:8000/appointments/update/${id}/`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status }),
    })
    .then(async (res) => {
      const resData = await res.json();
      if (!res.ok) {
        alert(resData.error || "Action failed");
      } else {
        fetchAppointments();
      }
    })
    .catch(err => console.error("Update error:", err));
  };

  return (
    <div className="appointment-page">
      <div className="header-section">
        <h2 className="main-title">All Appointments</h2>
      </div>

      <div className="tablecontainer">
        <div className="table-header-gridd">
          <span>PATIENT DETAILS</span>
          <span>SERVICE</span>
          <span>DATE & STATUS</span>
          <span className="text-right">ACTIONS</span>
        </div>

        <div className="cards-list">
          {data.length > 0 ? data.map((item) => (
            <div key={item.id} className="appointment-card-roww">
              <div className="col-patient">
                <div className="avatar-box">{item.patient_name ? item.patient_name.charAt(0) : "P"}</div>
                <div className="patient-text">
                  <div className="p-name">{item.patient_name}</div>
                  {/* <div className="p-sub">ID: #{item.patient_serial ? item.patient_serial : item.id.slice(-5).toUpperCase()}</div> */}
                  <div className="p-sub">ID-{item.patient_serial}</div>

                </div>
              </div>

              <div className="col-service">
                <span className="service-chip">{item.service}</span>
              </div>

              <div className="col-status">
                <div className="d-text">{new Date(item.date).toLocaleDateString()}</div>
                <div className={`status-badgee ${item.status.toLowerCase()}`}>
                  {item.status}
                </div>
              </div>

              <div className="col-actions">
                <button 
                  title="Approve" 
                  disabled={item.status !== "Pending"}
                  className={`btn-icon-round approve ${item.status !== "Pending" ? "btn-disabled" : ""}`} 
                  onClick={() => updateStatus(item.id, 'Approved')}
                >
                  <i className="bi bi-check-lg"></i>
                </button>

                <button 
                  title="Delay" 
                  disabled={item.status !== "Pending"}
                  className={`btn-icon-round delay ${item.status !== "Pending" ? "btn-disabled" : ""}`} 
                  onClick={() => updateStatus(item.id, 'Delay')}
                >
                  <i className="bi bi-clock"></i>
                </button>

                {/* VIEW BUTTON - Now sets the selectedPatient state */}
                <button 
                  title="View Details" 
                  className="btn-icon-round view" 
                  onClick={() => setSelectedPatient(item)}
                >
                  <i className="bi bi-eye"></i>
                </button>

                <button 
                  title="Cancel" 
                  disabled={item.status !== "Pending"}
                  className={`btn-icon-round delete ${item.status !== "Pending" ? "btn-disabled" : ""}`} 
                  onClick={() => updateStatus(item.id, 'Cancelled')}
                >
                  <i className="bi bi-trash"></i>
                </button>
              </div>
            </div>
          )) : (
            <div className="empty-state">No appointments found.</div>
          )}
        </div>
      </div>

      {/* --- PATIENT DETAIL MODAL --- */}
      {/* {selectedPatient && (
        <div className="modal-overlay" onClick={() => setSelectedPatient(null)}>
          <div className="modal-card detail-modal" onClick={e => e.stopPropagation()}>
            <div className="modal-header">
              <h3>Appointment Details</h3>
              <button className="close-x" onClick={() => setSelectedPatient(null)}>&times;</button>
            </div>
            <div className="modal-body">
              <div className="detail-avatar-section">
                <div className="detail-avatar">{selectedPatient.patient_name.charAt(0)}</div>
                <h4>{selectedPatient.patient_name}</h4>
                <p>Patient Record #{selectedPatient.id.slice(-8).toUpperCase()}</p>
              </div>
              
              <div className="detail-grid">
                <div className="detail-item">
                  <label>Service Type</label>
                  <span>{selectedPatient.service}</span>
                </div>
                <div className="detail-item">
                  <label>Appointment Date</label>
                  <span>{new Date(selectedPatient.date).toLocaleDateString('en-GB', { dateStyle: 'full' })}</span>
                </div>
                <div className="detail-item">
                  <label>Current Status</label>
                  <span className={`status-text ${selectedPatient.status.toLowerCase()}`}>
                    {selectedPatient.status}
                  </span>
                </div>
                <div className="detail-item">
                  <label>Full Reference ID</label>
                  <code className="ref-code">{selectedPatient.id}</code>
                </div>
              </div>
            </div>
            <div className="modal-footer">
              <button className="btn-close-modal" onClick={() => setSelectedPatient(null)}>Close</button>
            </div>
          </div>
        </div>
      )} */}
      {selectedPatient && (
  <div className="modal-overlay" onClick={() => setSelectedPatient(null)}>
    <div className="detail-modal" onClick={e => e.stopPropagation()}>

      <div className="modal-header-top">
  <button className="close-x" onClick={() => setSelectedPatient(null)}>&times;</button>
  {/* Status Pill */}
  <div className="detail-status-pill">
    <span className="dot"></span>
    {selectedPatient.status}
  </div>
  <div className="detail-avatar">{selectedPatient.patient_name.charAt(0)}</div>
  <h3>{selectedPatient.patient_name}</h3>
  
  {/* Yahan Serial Number dikhayein */}
  <p>Patient Serial &nbsp;#&nbsp;{selectedPatient.patient_serial || selectedPatient.id.slice(-5).toUpperCase()}</p>
</div>

      <div className="modal-body">
        <div className="ref-strip">
          <span className="ref-label">Reference ID</span>
          <code>{selectedPatient.id}</code>
        </div>

        <div className="detail-info-grid">
          <div className="detail-info-card">
            <div className="ic-icon">🩺</div>
            <div className="ic-label">Service type</div>
            <div className="ic-value">{selectedPatient.service}</div>
          </div>
          <div className="detail-info-card">
            <div className="ic-icon">📅</div>
            <div className="ic-label">Appointment date</div>
            <div className="ic-value">
              {new Date(selectedPatient.date).toLocaleDateString('en-GB', { dateStyle: 'full' })}
            </div>
          </div>
          <div className="detail-info-card">
            <div className="ic-icon">✅</div>
            <div className="ic-label">Current status</div>
            <div className={`ic-value ${selectedPatient.status.toLowerCase()}`}>
              {selectedPatient.status}
            </div>
          </div>
          <div className="detail-info-card">
            <div className="ic-icon">🔖</div>
            <div className="ic-label">Record ID</div>
            <div className="ic-value">{selectedPatient.id.slice(-8).toUpperCase()}</div>
          </div>
        </div>

        <div className="modal-action-row">
          {/* <button
            className="btn-modal-approve"
            disabled={selectedPatient.status !== "Pending"}
            onClick={() => { updateStatus(selectedPatient.id, 'Approved'); setSelectedPatient(null); }}
          >
            Approve
          </button> */}
          <button className="btn-modal-close" onClick={() => setSelectedPatient(null)}>
            Close
          </button>
        </div>
      </div>

    </div>
  </div>
)}
    </div>
  );
}

export default Appointments;